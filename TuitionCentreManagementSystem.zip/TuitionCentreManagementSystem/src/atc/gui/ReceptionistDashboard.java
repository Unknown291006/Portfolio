package atc.gui;

import atc.auth.Authenticator;
import atc.auth.ClassManager;
import atc.auth.EnrollmentManager;
import atc.data.ClassScheduleManager;
import atc.data.PaymentManager;
import atc.data.RequestManager;
import atc.data.StudentDataManager;
import atc.model.*; // This imports all your model classes
import atc.model.SubjectManager; // Explicitly import SubjectManager

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays; // No longer strictly needed for SUBJECTS array
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

public class ReceptionistDashboard extends JFrame {
    private User receptionistUser;

    // Managers (instantiated once and reused)
    private Authenticator authenticator;
    private StudentDataManager studentDataManager;
    private EnrollmentManager enrollmentManager;
    private ClassScheduleManager classScheduleManager; // For getting available subjects/classes
    private ClassManager classManager; // For getting actual ClassInfo objects
    private RequestManager requestManager;
    // PaymentManager is static, so direct calls will be used.

    // UI Components for various panels
    private JTabbedPane tabbedPane;

    // --- Register & Enroll Student Tab ---
    private JTextField regNameField, regIcPassportField, regEmailField, regContactNumberField, regAddressField, regUserIdField;
    private JPasswordField regPasswordField;
    private JComboBox<String> regLevelComboBox;
    private JList<String> regAvailableSubjectsList;
    private DefaultListModel<String> regAvailableSubjectsListModel;
    private JButton registerAndEnrollButton;

    // --- Manage Enrollments Tab ---
    private JComboBox<String> manageEnrollStudentComboBox; // For selecting student
    private JTable manageEnrollmentTable;
    private DefaultTableModel manageEnrollmentTableModel;
    private JButton deleteEnrollmentButton;
    private JButton updateEnrollmentButton; // To trigger a dialog for updating subjects

    // --- Accept Payments Tab ---
    private JComboBox<String> paymentStudentComboBox;
    private JLabel paymentBalanceDueLabel;
    private JTextField paymentAmountField;
    private JButton acceptPaymentButton;

    // --- Handle Subject Requests Tab ---
    private JTable requestsTable;
    private DefaultTableModel requestsTableModel;
    private JButton acceptRequestButton, denyRequestButton;

    // --- Delete Student Tab ---
    private JComboBox<String> deleteStudentComboBox;
    private JButton deleteStudentButton;

    // --- Update Profile Tab ---
    private JTextField profileUserIdField;
    private JPasswordField profileCurrentPasswordField, profileNewPasswordField, profileConfirmNewPasswordField;
    private JButton profileUpdatePasswordButton;

    // Hardcoded data for combos
    private final String[] LEVELS = {"Secondary 1", "Secondary 2", "Secondary 3", "Secondary 4", "Secondary 5"}; // Expanded based on AdminDashboard
    private final String[] SUBJECTS = {"Mathematics", "Science", "English", "Physics", "Chemistry", "Biology", "AddMath"};
    // private final String[] SUBJECTS; // REMOVED - will be loaded from SubjectManager


    public ReceptionistDashboard(User receptionistUser) {
        this.receptionistUser = receptionistUser;

        // Initialize Managers
        this.authenticator = new Authenticator();
        this.studentDataManager = new StudentDataManager();
        this.enrollmentManager = new EnrollmentManager();
        this.classScheduleManager = new ClassScheduleManager();
        this.classManager = new ClassManager();
        this.requestManager = new RequestManager();
        // PaymentManager is static, no instance needed

        setTitle("ATC Receptionist Dashboard - Welcome, " + receptionistUser.getUserId());
        setSize(1000, 750); // Increased size for more content
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Apply Black and White UI Settings
        applyBlackAndWhiteTheme(this);

        initComponents();
        addListeners();
        setVisible(true);
        refreshAllData(); // Load initial data for all panels
    }

    // Helper method to apply theme recursively
    private void applyBlackAndWhiteTheme(Component component) {
        component.setBackground(Color.WHITE);
        if (component instanceof JComponent) {
            JComponent jc = (JComponent) component;
            jc.setForeground(Color.BLACK); // Default text color

            if (jc instanceof JPanel || jc instanceof JTabbedPane || jc instanceof JScrollPane || jc instanceof JViewport) {
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JLabel || jc instanceof JComboBox || jc instanceof JList || jc instanceof JMenuItem || jc instanceof JMenu) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JTextField || jc instanceof JPasswordField || jc instanceof JTextArea) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            }
            if (jc instanceof JButton) {
                jc.setForeground(Color.WHITE);
                jc.setBackground(Color.BLACK);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            }
            if (jc instanceof JTable) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                JTable table = (JTable) jc;
                if (table.getTableHeader() != null) {
                    table.getTableHeader().setBackground(Color.BLACK);
                    table.getTableHeader().setForeground(Color.WHITE);
                }
            }
        }
        if (component instanceof JMenuBar) {
            component.setBackground(Color.WHITE);
            component.setForeground(Color.BLACK);
        }

        if (component instanceof Container) {
            for (Component child : ((Container) component).getComponents()) {
                applyBlackAndWhiteTheme(child);
            }
        }
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(mainPanel);

        // Top Panel for Title and Logout
        JPanel topPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(topPanel);
        JLabel titleLabel = new JLabel("Receptionist Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 12));
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(logoutPanel);
        logoutPanel.add(logoutButton);
        topPanel.add(logoutPanel, BorderLayout.EAST);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Tabbed Pane
        tabbedPane = new JTabbedPane();
        applyBlackAndWhiteTheme(tabbedPane);
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));

        tabbedPane.addTab("Register & Enroll Student", createRegisterEnrollStudentPanel());
        tabbedPane.addTab("Manage Enrollments", createManageEnrollmentsPanel());
        tabbedPane.addTab("Accept Payments", createAcceptPaymentsPanel());
        tabbedPane.addTab("Handle Subject Requests", createHandleSubjectRequestsPanel());
        tabbedPane.addTab("Delete Student", createDeleteStudentPanel());
        tabbedPane.addTab("Update Profile", createUpdateProfilePanel());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        add(mainPanel);

        // Logout Listener (common)
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new LoginScreen();
                dispose();
            }
        });
    }

    private void addListeners() {
        // Listeners for individual panels are added within their creation methods
    }

    // --- Panel: Register & Enroll Student ---
    private JPanel createRegisterEnrollStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("New Student Registration & Enrollment", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        // Form for Student Details
        JPanel formPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(formPanel);
        formPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Student Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("User ID (for login):"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regUserIdField = new JTextField(20); formPanel.add(regUserIdField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regPasswordField = new JPasswordField(20); formPanel.add(regPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regNameField = new JTextField(20); formPanel.add(regNameField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("IC/Passport:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regIcPassportField = new JTextField(20); formPanel.add(regIcPassportField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regEmailField = new JTextField(20); formPanel.add(regEmailField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Contact Number:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regContactNumberField = new JTextField(20); formPanel.add(regContactNumberField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST; regAddressField = new JTextField(20); formPanel.add(regAddressField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Level (Form/Primary):"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        regLevelComboBox = new JComboBox<>(LEVELS);
        regLevelComboBox.addActionListener(e -> updateAvailableSubjectsList()); // Update subjects when level changes
        formPanel.add(regLevelComboBox, gbc);

        panel.add(formPanel, BorderLayout.CENTER);

        // Subject Selection (Right Side)
        JPanel subjectSelectionPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(subjectSelectionPanel);
        subjectSelectionPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Select Subjects (Max 3)"));

        regAvailableSubjectsListModel = new DefaultListModel<>();
        regAvailableSubjectsList = new JList<>(regAvailableSubjectsListModel);
        regAvailableSubjectsList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        regAvailableSubjectsList.setVisibleRowCount(8);
        JScrollPane subjectScrollPane = new JScrollPane(regAvailableSubjectsList);
        applyBlackAndWhiteTheme(subjectScrollPane);
        subjectSelectionPanel.add(subjectScrollPane, BorderLayout.CENTER);

        panel.add(subjectSelectionPanel, BorderLayout.EAST); // Place to the right of the form

        registerAndEnrollButton = new JButton("Register & Enroll Student");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        applyBlackAndWhiteTheme(buttonPanel);
        buttonPanel.add(registerAndEnrollButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);


        registerAndEnrollButton.addActionListener(e -> registerAndEnrollStudent());
        regLevelComboBox.setSelectedIndex(0); // Trigger initial subject list update

        return panel;
    }

    private void updateAvailableSubjectsList() {
        regAvailableSubjectsListModel.clear();
        String selectedLevel = (String) regLevelComboBox.getSelectedItem();

        System.out.println("DEBUG: Selected Level for Subjects: " + selectedLevel); // DEBUG 1

        if (selectedLevel == null || selectedLevel.isEmpty()) {
            System.out.println("DEBUG: Selected level is null or empty. Exiting subject update."); // DEBUG 2
            return;
        }

        // Load all classes from the manager
        List<ClassInfo> allClasses = classManager.getAllClasses();
        System.out.println("DEBUG: Total classes loaded by ClassManager: " + allClasses.size()); // DEBUG 3

        // Filter classes relevant to the selected level
        List<String> allClassesForSelectedLevelSubjects = allClasses.stream()
                .filter(c -> c.getLevel().equalsIgnoreCase(selectedLevel))
                .map(ClassInfo::getSubject)
                .distinct()
                .collect(Collectors.toList());
        System.out.println("DEBUG: Subjects with classes for selected level (" + selectedLevel + "): " + allClassesForSelectedLevelSubjects); // DEBUG 4


        // Use the hardcoded SUBJECTS array to populate the list
        List<String> subjectsToShow = new ArrayList<>();
        Arrays.stream(this.SUBJECTS)
                .filter(subjectName -> {
                    boolean hasClass = allClassesForSelectedLevelSubjects.contains(subjectName);
                    if (!hasClass) {
                        System.out.println("DEBUG: Subject '" + subjectName + "' for level '" + selectedLevel + "' has NO corresponding ClassInfo."); // DEBUG 5
                    }
                    return hasClass;
                })
                .sorted()
                .forEach(subjectsToShow::add); // Add to a temporary list first

        System.out.println("DEBUG: Final subjects to be added to JList: " + subjectsToShow); // DEBUG 6
        subjectsToShow.forEach(regAvailableSubjectsListModel::addElement); // Add to the actual model
    }


    private void registerAndEnrollStudent() {
        String userId = regUserIdField.getText().trim();
        String password = new String(regPasswordField.getPassword()).trim();
        String name = regNameField.getText().trim();
        String icPassport = regIcPassportField.getText().trim();
        String email = regEmailField.getText().trim();
        String contactNumber = regContactNumberField.getText().trim();
        String address = regAddressField.getText().trim();
        String level = (String) regLevelComboBox.getSelectedItem();
        List<String> selectedSubjects = regAvailableSubjectsList.getSelectedValuesList();

        if (userId.isEmpty() || password.isEmpty() || name.isEmpty() || icPassport.isEmpty() ||
                email.isEmpty() || contactNumber.isEmpty() || address.isEmpty() || level == null) {
            JOptionPane.showMessageDialog(this, "Please fill in all student details.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (selectedSubjects.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select at least one subject for enrollment.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (selectedSubjects.size() > 3) {
            JOptionPane.showMessageDialog(this, "You can enroll a student in a maximum of 3 subjects.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 1. Register User (Student)
        Student newStudent = new Student(userId, password); // Basic student user
        if (!authenticator.addUser(newStudent)) {
            JOptionPane.showMessageDialog(this, "User ID '" + userId + "' already exists. Please choose a different one.", "Registration Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Register Student Details & Calculate Initial Balance Due
        double totalCharges = 0;
        List<SubjectClass> allSchedules = classScheduleManager.loadClassSchedules();
        for (String subjectName : selectedSubjects) {
            SubjectClass sc = allSchedules.stream()
                    .filter(s -> s.getSubjectName().equalsIgnoreCase(subjectName) && s.getLevel().equalsIgnoreCase(level))
                    .findFirst()
                    .orElse(null);
            if (sc != null) {
                totalCharges += sc.getCharges();
            } else {
                JOptionPane.showMessageDialog(this, "Could not find class schedule for " + subjectName + " at " + level + ". Charges might be incorrect.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }

        // Create the full Student object
        Student studentWithDetails = new Student(userId, password, name, icPassport, email, contactNumber,
                address, level, selectedSubjects, totalCharges, new ArrayList<>()); // No pending requests initially
        StudentDataManager.updateStudent(studentWithDetails); // Save comprehensive student data
        //Modification Start
        // Load all existing students
        List<Student> allExistingStudents = studentDataManager.loadStudents();
        // Add the new student to the list
        allExistingStudents.add(studentWithDetails);
        // Save the entire updated list back to the file
        studentDataManager.saveStudents(allExistingStudents);

        //Modification End
        // 3. Enroll Student in Subjects (create Enrollment records)
        boolean allEnrollmentsSuccessful = true;
        for (String subjectName : selectedSubjects) {
            // Find a ClassInfo for this subject and level. (Assuming one class per subject/level combination for simplicity for now)
            Optional<ClassInfo> classOpt = classManager.getAllClasses().stream()
                    .filter(c -> c.getSubject().equalsIgnoreCase(subjectName) && c.getLevel().equalsIgnoreCase(level))
                    .findFirst();

            if (classOpt.isPresent()) {
                ClassInfo classInfo = classOpt.get();
                // Check if student is already enrolled in this class to avoid duplicates (though addEnrollment should handle this too)
                if (enrollmentManager.getEnrollmentsByStudent(userId).stream().noneMatch(e -> e.getClassId().equals(classInfo.getClassId()))) {
                    Enrollment newEnrollment = new Enrollment(UUID.randomUUID().toString(), userId, classInfo.getClassId(), LocalDate.now());
                    if (!enrollmentManager.addEnrollment(newEnrollment)) {
                        allEnrollmentsSuccessful = false;
                        JOptionPane.showMessageDialog(this, "Failed to create enrollment for " + subjectName + " (" + classInfo.getClassId() + ").", "Enrollment Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                allEnrollmentsSuccessful = false;
                JOptionPane.showMessageDialog(this, "No class found for subject: " + subjectName + " at level: " + level + ". Enrollment skipped for this subject.", "Enrollment Warning", JOptionPane.WARNING_MESSAGE);
            }
        }

        if (allEnrollmentsSuccessful) {
            JOptionPane.showMessageDialog(this, "Student " + userId + " registered and enrolled successfully! Initial Balance Due: RM " + String.format("%.2f", totalCharges), "Success", JOptionPane.INFORMATION_MESSAGE);
            clearRegistrationFields();
            refreshAllData(); // Refresh other relevant tables
        } else {
            JOptionPane.showMessageDialog(this, "Student registered, but some enrollments failed. Please check logs.", "Partial Success", JOptionPane.WARNING_MESSAGE);
            // Optionally, consider rolling back if partial enrollment is not desired
            refreshAllData();
        }
    }

    private void clearRegistrationFields() {
        regUserIdField.setText("");
        regPasswordField.setText("");
        regNameField.setText("");
        regIcPassportField.setText("");
        regEmailField.setText("");
        regContactNumberField.setText("");
        regAddressField.setText("");
        regLevelComboBox.setSelectedIndex(0);
        regAvailableSubjectsList.clearSelection();
    }


    // --- Panel: Manage Enrollments ---
    private JPanel createManageEnrollmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Manage Student Enrollments", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        // Controls for student selection
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        applyBlackAndWhiteTheme(controlPanel);
        manageEnrollStudentComboBox = new JComboBox<>();
        applyBlackAndWhiteTheme(manageEnrollStudentComboBox);
        controlPanel.add(new JLabel("Select Student:"));
        controlPanel.add(manageEnrollStudentComboBox);
        panel.add(controlPanel, BorderLayout.NORTH);

        // Table for enrollments
        String[] columnNames = {"Enrollment ID", "Student ID", "Class ID", "Subject", "Level", "Tutor", "Enrollment Date"};
        manageEnrollmentTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        manageEnrollmentTable = new JTable(manageEnrollmentTableModel);
        applyBlackAndWhiteTheme(manageEnrollmentTable);
        JScrollPane scrollPane = new JScrollPane(manageEnrollmentTable);
        applyBlackAndWhiteTheme(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Buttons for actions
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        applyBlackAndWhiteTheme(buttonPanel);
        deleteEnrollmentButton = new JButton("Delete Selected Enrollment");
        updateEnrollmentButton = new JButton("Update Selected Student's Subjects");
        buttonPanel.add(deleteEnrollmentButton);
        buttonPanel.add(updateEnrollmentButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Listeners
        manageEnrollStudentComboBox.addActionListener(e -> loadStudentEnrollments());
        deleteEnrollmentButton.addActionListener(e -> deleteSelectedEnrollment());
        updateEnrollmentButton.addActionListener(e -> showUpdateEnrollmentDialog());

        return panel;
    }

    private void loadStudentEnrollments() {
        manageEnrollmentTableModel.setRowCount(0); // Clear existing data
        String selectedStudentId = (String) manageEnrollStudentComboBox.getSelectedItem();

        if (selectedStudentId == null || selectedStudentId.isEmpty()) {
            return;
        }

        List<Enrollment> studentEnrollments = enrollmentManager.getEnrollmentsByStudent(selectedStudentId);
        List<ClassInfo> allClasses = classManager.getAllClasses();
        // Removed allSubjectSchedules as it's not directly used for display in this loop

        if (studentEnrollments.isEmpty()) {
            manageEnrollmentTableModel.addRow(new Object[]{"No enrollments found for this student.", "", "", "", "", "", ""});
        } else {
            for (Enrollment enrollment : studentEnrollments) {
                String classId = enrollment.getClassId();
                Optional<ClassInfo> classInfoOpt = allClasses.stream().filter(c -> c.getClassId().equals(classId)).findFirst();
                if (classInfoOpt.isPresent()) {
                    ClassInfo ci = classInfoOpt.get();

                    manageEnrollmentTableModel.addRow(new Object[]{
                            enrollment.getEnrollmentId(),
                            enrollment.getStudentId(),
                            classId,
                            ci.getSubject(),
                            ci.getLevel(),
                            ci.getTutorId(), // Assuming ClassInfo holds tutor ID
                            enrollment.getEnrollmentDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                    });
                } else {
                    manageEnrollmentTableModel.addRow(new Object[]{
                            enrollment.getEnrollmentId(),
                            enrollment.getStudentId(),
                            classId,
                            "N/A (Class Deleted)", "N/A", "N/A",
                            enrollment.getEnrollmentDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                    });
                }
            }
        }
    }

    private void deleteSelectedEnrollment() {
        int selectedRow = manageEnrollmentTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an enrollment to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String enrollmentId = (String) manageEnrollmentTableModel.getValueAt(selectedRow, 0);
        String studentId = (String) manageEnrollmentTableModel.getValueAt(selectedRow, 1);
        String classId = (String) manageEnrollmentTableModel.getValueAt(selectedRow, 2);
        String subjectName = (String) manageEnrollmentTableModel.getValueAt(selectedRow, 3); // Subject
        String level = (String) manageEnrollmentTableModel.getValueAt(selectedRow, 4); // Level

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete enrollment " + enrollmentId + " for " + studentId + " (" + subjectName + ")?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (enrollmentManager.deleteEnrollment(enrollmentId)) {
                // Also update student's enrolled subjects and balance due
                Student student = studentDataManager.getStudentByUserId(studentId);
                if (student != null) {
                    student.getEnrolledSubjects().remove(subjectName); // Remove subject from student's list

                    // Deduct charges from balance due
                    SubjectClass sc = classScheduleManager.loadClassSchedules().stream()
                            .filter(s -> s.getSubjectName().equalsIgnoreCase(subjectName) && s.getLevel().equalsIgnoreCase(level))
                            .findFirst().orElse(null);
                    if (sc != null) {
                        student.setBalanceDue(student.getBalanceDue() - sc.getCharges());
                    } else {
                        System.err.println("Could not find charges for " + subjectName + " to deduct.");
                    }
                    StudentDataManager.updateStudent(student);
                }

                JOptionPane.showMessageDialog(this, "Enrollment deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshAllData(); // Refresh all tables
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete enrollment.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showUpdateEnrollmentDialog() {
        String selectedStudentId = (String) manageEnrollStudentComboBox.getSelectedItem();
        if (selectedStudentId == null || selectedStudentId.isEmpty() || manageEnrollmentTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please select a student to update their subjects.", "No Student Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Student student = studentDataManager.getStudentByUserId(selectedStudentId);
        if (student == null) {
            JOptionPane.showMessageDialog(this, "Student data not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Capture the original enrolled subjects for comparison later
        final List<String> originalEnrolledSubjects = new ArrayList<>(student.getEnrolledSubjects());

        JDialog updateDialog = new JDialog(this, "Update Subjects for " + student.getName(), true);
        updateDialog.setLayout(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(updateDialog);
        updateDialog.setSize(500, 400);
        updateDialog.setLocationRelativeTo(this);

        JPanel contentPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(contentPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Current subjects display (Optional - can be removed if the main list is enough)
        // Keeping for clarity initially, user will make selections in the list below
        JLabel currentSubjectsLabel = new JLabel("Currently Enrolled:");
        JTextArea currentSubjectsArea = new JTextArea(String.join(", ", originalEnrolledSubjects)); // Use comma for better display
        currentSubjectsArea.setEditable(false);
        currentSubjectsArea.setRows(1); // One row for a compact display
        currentSubjectsArea.setLineWrap(true);
        currentSubjectsArea.setWrapStyleWord(true);
        JScrollPane currentSubjectsScrollPane = new JScrollPane(currentSubjectsArea);
        applyBlackAndWhiteTheme(currentSubjectsScrollPane);

        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.NORTHWEST; contentPanel.add(currentSubjectsLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0; gbc.weighty = 0.1; contentPanel.add(currentSubjectsScrollPane, gbc);


        // --- MODIFIED: Available subjects for selection (will pre-select current ones) ---
        JLabel selectNewSubjectsLabel = new JLabel("Select All Desired Subjects (Max 3):"); // Changed label
        DefaultListModel<String> dialogAvailableSubjectsListModel = new DefaultListModel<>();
        JList<String> dialogAvailableSubjectsList = new JList<>(dialogAvailableSubjectsListModel);
        dialogAvailableSubjectsList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane dialogSubjectScrollPane = new JScrollPane(dialogAvailableSubjectsList);
        applyBlackAndWhiteTheme(dialogSubjectScrollPane);

        // Populate available subjects: All possible subjects for student's level, pre-selected if currently enrolled
        List<String> allClassesForStudentLevelSubjects = classManager.getAllClasses().stream()
                .filter(c -> c.getLevel().equalsIgnoreCase(student.getLevel()))
                .map(ClassInfo::getSubject)
                .distinct()
                .collect(Collectors.toList());

        List<String> subjectsToPopulateList = Arrays.stream(this.SUBJECTS)
                .filter(subjectName -> allClassesForStudentLevelSubjects.contains(subjectName)) // Only show subjects that have classes for this level
                .distinct()
                .sorted()
                .collect(Collectors.toList());

        // Populate the model and pre-select currently enrolled subjects
        int[] initialSelections = new int[originalEnrolledSubjects.size()];
        int selectionIndex = 0;

        for (int i = 0; i < subjectsToPopulateList.size(); i++) {
            String subject = subjectsToPopulateList.get(i);
            dialogAvailableSubjectsListModel.addElement(subject);
            if (originalEnrolledSubjects.contains(subject)) {
                initialSelections[selectionIndex++] = i;
            }
        }
        dialogAvailableSubjectsList.setSelectedIndices(initialSelections); // Set initial selections

        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.NORTHWEST; contentPanel.add(selectNewSubjectsLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0; gbc.weighty = 1.0; contentPanel.add(dialogSubjectScrollPane, gbc);

        // Buttons
        JPanel dialogButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(dialogButtonPanel);
        JButton saveButton = new JButton("Save Changes");
        JButton cancelButton = new JButton("Cancel");
        dialogButtonPanel.add(saveButton);
        dialogButtonPanel.add(cancelButton);

        updateDialog.add(contentPanel, BorderLayout.CENTER);
        updateDialog.add(dialogButtonPanel, BorderLayout.SOUTH);

        // Save Button Listener
        saveButton.addActionListener(e -> {
            List<String> newlySelectedSubjects = dialogAvailableSubjectsList.getSelectedValuesList();

            if (newlySelectedSubjects.isEmpty() && !originalEnrolledSubjects.isEmpty()) {
                int confirmClear = JOptionPane.showConfirmDialog(updateDialog, "You have deselected all subjects. Are you sure you want to unenroll from everything?", "Confirm Unenrollment", JOptionPane.YES_NO_OPTION);
                if (confirmClear == JOptionPane.NO_OPTION) {
                    return; // Do not proceed with saving if user cancels unenrollment
                }
            }

            if (newlySelectedSubjects.size() > 3) {
                JOptionPane.showMessageDialog(updateDialog, "Total subjects for student cannot exceed 3. Please select up to 3 subjects.", "Enrollment Limit Exceeded", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Determine subjects to ADD and subjects to REMOVE
            List<String> subjectsToAdd = newlySelectedSubjects.stream()
                    .filter(subject -> !originalEnrolledSubjects.contains(subject))
                    .collect(Collectors.toList());

            List<String> subjectsToRemove = originalEnrolledSubjects.stream()
                    .filter(subject -> !newlySelectedSubjects.contains(subject))
                    .collect(Collectors.toList());

            // Check if any actual changes were made
            if (subjectsToAdd.isEmpty() && subjectsToRemove.isEmpty()) {
                JOptionPane.showMessageDialog(updateDialog, "No changes detected. Subjects remain the same.", "No Changes", JOptionPane.INFORMATION_MESSAGE);
                updateDialog.dispose();
                return;
            }

            // Process changes:
            double balanceChange = 0;
            boolean partialEnrollmentFailure = false;
            List<SubjectClass> allSchedules = classScheduleManager.loadClassSchedules(); // Load this once

            // --- 1. Process subjects to REMOVE ---
            for (String subjectToRemove : subjectsToRemove) {
                // Remove from student's enrolled subjects list in memory
                student.getEnrolledSubjects().remove(subjectToRemove);

                // Find and delete the corresponding enrollment record
                Optional<Enrollment> enrollmentToDeleteOpt = enrollmentManager.getEnrollmentsByStudent(student.getUserId()).stream()
                        .filter(enr -> classManager.getClassById(enr.getClassId()) // Get ClassInfo for the enrollment
                                .map(ci -> ci.getSubject().equalsIgnoreCase(subjectToRemove))
                                .orElse(false))
                        .findFirst();

                if (enrollmentToDeleteOpt.isPresent()) {
                    Enrollment enrollmentToDelete = enrollmentToDeleteOpt.get();
                    if (enrollmentManager.deleteEnrollment(enrollmentToDelete.getEnrollmentId())) {
                        // Deduct charges from balance due
                        SubjectClass sc = allSchedules.stream()
                                .filter(s -> s.getSubjectName().equalsIgnoreCase(subjectToRemove) && s.getLevel().equalsIgnoreCase(student.getLevel()))
                                .findFirst().orElse(null);
                        if (sc != null) {
                            balanceChange -= sc.getCharges();
                        } else {
                            System.err.println("Warning: Could not find charges for removed subject " + subjectToRemove + ". Balance might be incorrect.");
                        }
                    } else {
                        partialEnrollmentFailure = true;
                        System.err.println("Failed to delete enrollment record for " + subjectToRemove);
                    }
                } else {
                    System.err.println("Warning: Enrollment record not found for " + subjectToRemove + " for student " + student.getUserId());
                }
            }


            // --- 2. Process subjects to ADD ---
            for (String subjectToAdd : subjectsToAdd) {
                // Add to student's enrolled subjects list in memory
                student.getEnrolledSubjects().add(subjectToAdd);

                // Create new Enrollment record
                Optional<ClassInfo> classOpt = classManager.getAllClasses().stream()
                        .filter(c -> c.getSubject().equalsIgnoreCase(subjectToAdd) && c.getLevel().equalsIgnoreCase(student.getLevel()))
                        .findFirst();

                if (classOpt.isPresent()) {
                    ClassInfo classInfo = classOpt.get();
                    // Double check if enrollment already exists (shouldn't if filtered correctly)
                    if (enrollmentManager.getEnrollmentsByStudent(student.getUserId()).stream().noneMatch(enrollment -> enrollment.getClassId().equals(classInfo.getClassId()))) {
                        Enrollment newEnrollment = new Enrollment(UUID.randomUUID().toString(), student.getUserId(), classInfo.getClassId(), LocalDate.now());
                        if (enrollmentManager.addEnrollment(newEnrollment)) {
                            // Add charges for new subject
                            SubjectClass sc = allSchedules.stream()
                                    .filter(s -> s.getSubjectName().equalsIgnoreCase(subjectToAdd) && s.getLevel().equalsIgnoreCase(student.getLevel()))
                                    .findFirst().orElse(null);
                            if (sc != null) {
                                balanceChange += sc.getCharges();
                            } else {
                                System.err.println("Warning: Could not find charges for added subject " + subjectToAdd + ". Balance might be incorrect.");
                            }
                        } else {
                            partialEnrollmentFailure = true;
                            System.err.println("Failed to add new enrollment record for " + subjectToAdd);
                        }
                    }
                } else {
                    partialEnrollmentFailure = true;
                    JOptionPane.showMessageDialog(updateDialog, "No class found for " + subjectToAdd + " at student's level. Enrollment not created.", "Error", JOptionPane.ERROR_MESSAGE);
                    // Remove from student's list if enrollment failed due to no class
                    student.getEnrolledSubjects().remove(subjectToAdd);
                }
            }

            // --- 3. Update Student's enrolled subjects and balance due (after all adds/removes) ---
            // The student.getEnrolledSubjects() list has been modified directly above.
            // Now update the balance.
            student.setBalanceDue(student.getBalanceDue() + balanceChange);
            StudentDataManager.updateStudent(student); // Save updated comprehensive student data

            String message = "Student subjects updated successfully!";
            if (balanceChange != 0) {
                message += String.format(" Balance adjusted by RM %.2f. New Balance: RM %.2f", balanceChange, student.getBalanceDue());
            }
            JOptionPane.showMessageDialog(updateDialog, message, "Update Successful", JOptionPane.INFORMATION_MESSAGE);

            if (partialEnrollmentFailure) {
                JOptionPane.showMessageDialog(updateDialog, "Some enrollment changes could not be fully processed. Please check console for details.", "Partial Success", JOptionPane.WARNING_MESSAGE);
            }
            updateDialog.dispose();
            refreshAllData(); // Refresh tables after update
        });

        cancelButton.addActionListener(e -> updateDialog.dispose());

        updateDialog.setVisible(true);
    }
    // --- Panel: Accept Payments ---
    private JPanel createAcceptPaymentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Accept Student Payments", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Select Student:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        paymentStudentComboBox = new JComboBox<>();
        applyBlackAndWhiteTheme(paymentStudentComboBox);
        paymentStudentComboBox.addActionListener(e -> updatePaymentBalance());
        formPanel.add(paymentStudentComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Balance Due:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        paymentBalanceDueLabel = new JLabel("RM 0.00");
        paymentBalanceDueLabel.setFont(new Font("Arial", Font.BOLD, 16));
        paymentBalanceDueLabel.setForeground(Color.RED);
        formPanel.add(paymentBalanceDueLabel, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Payment Amount (RM):"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        paymentAmountField = new JTextField(15);
        formPanel.add(paymentAmountField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        acceptPaymentButton = new JButton("Accept Payment");
        formPanel.add(acceptPaymentButton, gbc);

        panel.add(formPanel, BorderLayout.CENTER);

        acceptPaymentButton.addActionListener(e -> acceptPayment());

        return panel;
    }

    private void updatePaymentBalance() {
        String selectedStudentId = (String) paymentStudentComboBox.getSelectedItem();
        if (selectedStudentId != null && !selectedStudentId.isEmpty()) {
            Student student = studentDataManager.getStudentByUserId(selectedStudentId);
            if (student != null) {
                paymentBalanceDueLabel.setText(String.format("RM %.2f", student.getBalanceDue()));
                paymentBalanceDueLabel.setForeground(student.getBalanceDue() > 0 ? Color.RED : Color.BLUE);
            } else {
                paymentBalanceDueLabel.setText("RM 0.00");
                paymentBalanceDueLabel.setForeground(Color.BLACK);
            }
        }
    }

    private void acceptPayment() {
        String studentId = (String) paymentStudentComboBox.getSelectedItem();
        if (studentId == null || studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a student.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Student student = studentDataManager.getStudentByUserId(studentId);
        if (student == null) {
            JOptionPane.showMessageDialog(this, "Student data not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        double amount;
        try {
            amount = Double.parseDouble(paymentAmountField.getText().trim());
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Payment amount must be positive.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid payment amount. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Update student's balance due
        double newBalance = student.getBalanceDue() - amount;
        student.setBalanceDue(newBalance);
        StudentDataManager.updateStudent(student); // Save updated student data

        // Record the payment
        List<Enrollment> studentEnrollments = enrollmentManager.getEnrollmentsByStudent(studentId);
        if (studentEnrollments.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student has no active enrollments. Payment accepted but not tied to a specific subject for reporting.", "Payment Accepted", JOptionPane.WARNING_MESSAGE);
            PaymentRecord genericPayment = new PaymentRecord(UUID.randomUUID().toString(), studentId, "General Tuition", student.getLevel(), amount, LocalDate.now());
            PaymentManager.addPayment(genericPayment);
        } else {
            // Let's go with a simplified prompt for now
            String[] enrolledSubjectsArray = student.getEnrolledSubjects().toArray(new String[0]);
            String subjectForPayment = (String) JOptionPane.showInputDialog(
                    this,
                    "Attribute payment to which subject for reporting?",
                    "Payment Attribution",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    enrolledSubjectsArray,
                    enrolledSubjectsArray.length > 0 ? enrolledSubjectsArray[0] : null
            );

            if (subjectForPayment != null) {
                PaymentRecord paymentRecord = new PaymentRecord(UUID.randomUUID().toString(), studentId, subjectForPayment, student.getLevel(), amount, LocalDate.now());
                PaymentManager.addPayment(paymentRecord);
            } else {
                JOptionPane.showMessageDialog(this, "Payment accepted, but no subject selected for reporting. Record will be generic.", "Payment Accepted", JOptionPane.WARNING_MESSAGE);
                PaymentRecord genericPayment = new PaymentRecord(UUID.randomUUID().toString(), studentId, "General Tuition", student.getLevel(), amount, LocalDate.now());
                PaymentManager.addPayment(genericPayment);
            }
        }


        // Generate Receipt (simplified)
        String receipt = String.format(
                "--- Payment Receipt ---\n" +
                        "Student ID: %s\n" +
                        "Student Name: %s\n" +
                        "Amount Paid: RM %.2f\n" +
                        "Date: %s\n" +
                        "New Balance Due: RM %.2f\n" +
                        "-----------------------",
                student.getUserId(), student.getName(), amount, LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), newBalance
        );
        JOptionPane.showMessageDialog(this, receipt, "Payment Receipt", JOptionPane.INFORMATION_MESSAGE);

        paymentAmountField.setText(""); // Clear field
        refreshAllData(); // Refresh UI including student's balance due
    }

    // --- Panel: Handle Subject Requests ---
    private JPanel createHandleSubjectRequestsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Handle Student Subject Change Requests", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"Request ID", "Student ID", "Current Subject", "New Subject", "Date Sent", "Status"};
        requestsTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        requestsTable = new JTable(requestsTableModel);
        applyBlackAndWhiteTheme(requestsTable);
        JScrollPane scrollPane = new JScrollPane(requestsTable);
        applyBlackAndWhiteTheme(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        applyBlackAndWhiteTheme(buttonPanel);
        acceptRequestButton = new JButton("Accept Request");
        denyRequestButton = new JButton("Deny Request");
        buttonPanel.add(acceptRequestButton);
        buttonPanel.add(denyRequestButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Listeners
        acceptRequestButton.addActionListener(e -> handleSubjectRequest(true));
        denyRequestButton.addActionListener(e -> handleSubjectRequest(false));

        return panel;
    }

    private void loadPendingRequests() {
        requestsTableModel.setRowCount(0);
        List<SubjectChangeRequest> allRequests = requestManager.loadRequests(); // Load all requests
        List<SubjectChangeRequest> pendingRequests = allRequests.stream()
                .filter(r -> r.getStatus().equalsIgnoreCase("Pending"))
                .collect(Collectors.toList());

        if (pendingRequests.isEmpty()) {
            requestsTableModel.addRow(new Object[]{"No pending requests.", "", "", "", "", ""});
        } else {
            for (SubjectChangeRequest req : pendingRequests) {
                requestsTableModel.addRow(new Object[]{
                        req.getRequestId(),
                        req.getStudentId(),
                        req.getCurrentSubject() != null ? req.getCurrentSubject() : "N/A (Adding)",
                        req.getNewSubject() != null ? req.getNewSubject() : "N/A (Dropping)",
                        req.getRequestDate(),
                        req.getStatus()
                });
            }
        }
    }

    private void handleSubjectRequest(boolean accept) {
        int selectedRow = requestsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to " + (accept ? "accept" : "deny") + ".", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String requestId = (String) requestsTableModel.getValueAt(selectedRow, 0);
        String studentId = (String) requestsTableModel.getValueAt(selectedRow, 1);
        String currentSubjectToDrop = (String) requestsTableModel.getValueAt(selectedRow, 2);
        String newSubjectToAdd = (String) requestsTableModel.getValueAt(selectedRow, 3);

        SubjectChangeRequest requestToUpdate = requestManager.loadRequests().stream()
                .filter(r -> r.getRequestId().equals(requestId))
                .findFirst()
                .orElse(null);

        if (requestToUpdate == null) {
            JOptionPane.showMessageDialog(this, "Request not found in system. Please refresh.", "Error", JOptionPane.ERROR_MESSAGE);
            refreshAllData();
            return;
        }

        if (requestToUpdate.getStatus().equalsIgnoreCase("Accepted") || requestToUpdate.getStatus().equalsIgnoreCase("Denied")) {
            JOptionPane.showMessageDialog(this, "This request has already been processed.", "Request Already Handled", JOptionPane.WARNING_MESSAGE);
            refreshAllData();
            return;
        }

        Student student = studentDataManager.getStudentByUserId(studentId);
        if (student == null) {
            JOptionPane.showMessageDialog(this, "Student " + studentId + " not found. Cannot process request.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (accept) {
            // --- ACCEPT LOGIC ---
            double balanceChange = 0;
            List<String> studentEnrolledSubjects = new ArrayList<>(student.getEnrolledSubjects());
            List<Enrollment> enrollmentsToUpdate = enrollmentManager.getEnrollmentsByStudent(studentId);
            boolean enrollmentSuccess = true;

            // Handle dropping a subject
            if (!currentSubjectToDrop.equals("N/A (Adding)")) {
                if (studentEnrolledSubjects.contains(currentSubjectToDrop)) {
                    studentEnrolledSubjects.remove(currentSubjectToDrop); // Update student's list

                    // Find and delete the corresponding enrollment
                    Optional<Enrollment> enrollmentToDeleteOpt = enrollmentsToUpdate.stream()
                            .filter(e -> {
                                Optional<ClassInfo> ciOpt = classManager.getClassById(e.getClassId());
                                return ciOpt.isPresent() && ciOpt.get().getSubject().equalsIgnoreCase(currentSubjectToDrop);
                            })
                            .findFirst();

                    if (enrollmentToDeleteOpt.isPresent()) {
                        Enrollment enrollmentToDelete = enrollmentToDeleteOpt.get();
                        if (!enrollmentManager.deleteEnrollment(enrollmentToDelete.getEnrollmentId())) {
                            enrollmentSuccess = false;
                            System.err.println("Failed to delete enrollment " + enrollmentToDelete.getEnrollmentId());
                        }
                    }

                    // Deduct charges
                    SubjectClass sc = classScheduleManager.loadClassSchedules().stream()
                            .filter(s -> s.getSubjectName().equalsIgnoreCase(currentSubjectToDrop) && s.getLevel().equalsIgnoreCase(student.getLevel()))
                            .findFirst().orElse(null);
                    if (sc != null) {
                        balanceChange -= sc.getCharges();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Student is not enrolled in '" + currentSubjectToDrop + "'. Cannot drop.", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }

            // Handle adding a new subject
            if (!newSubjectToAdd.equals("N/A (Dropping)")) {
                if (!studentEnrolledSubjects.contains(newSubjectToAdd)) { // Only add if not already in list
                    // Check if adding this subject exceeds the 3 subject limit
                    if (studentEnrolledSubjects.size() >= 3) {
                        JOptionPane.showMessageDialog(this, "Student cannot enroll in more than 3 subjects. Denying addition of '" + newSubjectToAdd + "'.", "Enrollment Limit", JOptionPane.ERROR_MESSAGE);
                        enrollmentSuccess = false; // Mark as partial failure because of this
                    } else {
                        studentEnrolledSubjects.add(newSubjectToAdd); // Update student's list

                        // Create new enrollment
                        Optional<ClassInfo> classOpt = classManager.getAllClasses().stream()
                                .filter(c -> c.getSubject().equalsIgnoreCase(newSubjectToAdd) && c.getLevel().equalsIgnoreCase(student.getLevel()))
                                .findFirst();
                        if (classOpt.isPresent()) {
                            ClassInfo classInfo = classOpt.get();
                            Enrollment newEnrollment = new Enrollment(UUID.randomUUID().toString(), studentId, classInfo.getClassId(), LocalDate.now());
                            if (!enrollmentManager.addEnrollment(newEnrollment)) {
                                enrollmentSuccess = false;
                                System.err.println("Failed to add new enrollment for " + newSubjectToAdd);
                            }
                            // Add charges for new subject
                            SubjectClass sc = classScheduleManager.loadClassSchedules().stream()
                                    .filter(s -> s.getSubjectName().equalsIgnoreCase(newSubjectToAdd) && s.getLevel().equalsIgnoreCase(student.getLevel()))
                                    .findFirst().orElse(null);
                            if (sc != null) {
                                balanceChange += sc.getCharges();
                            }
                        } else {
                            enrollmentSuccess = false;
                            JOptionPane.showMessageDialog(this, "No class found for " + newSubjectToAdd + " at student's level. Enrollment not created.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Student is already enrolled in '" + newSubjectToAdd + "'.", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }

            // Update student object and save
            student.setEnrolledSubjects(studentEnrolledSubjects);
            student.setBalanceDue(student.getBalanceDue() + balanceChange);
            StudentDataManager.updateStudent(student);

            // Update request status
            requestToUpdate.setStatus("Accepted");
            List<SubjectChangeRequest> allRequests = requestManager.loadRequests();
            allRequests.removeIf(r -> r.getRequestId().equals(requestToUpdate.getRequestId())); // Remove old version
            allRequests.add(requestToUpdate); // Add updated version
            requestManager.saveRequests(allRequests);

            JOptionPane.showMessageDialog(this, "Request accepted! Student's subjects updated and balance adjusted by RM " + String.format("%.2f", balanceChange) + ". Current Balance: RM " + String.format("%.2f", student.getBalanceDue()), "Request Accepted", JOptionPane.INFORMATION_MESSAGE);
            if (!enrollmentSuccess) {
                JOptionPane.showMessageDialog(this, "Some enrollment changes could not be fully processed. Please check console for details.", "Partial Success", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            // --- DENY LOGIC ---
            requestToUpdate.setStatus("Denied");
            List<SubjectChangeRequest> allRequests = requestManager.loadRequests();
            allRequests.removeIf(r -> r.getRequestId().equals(requestToUpdate.getRequestId())); // Remove old version
            allRequests.add(requestToUpdate); // Add updated version
            requestManager.saveRequests(allRequests);
            JOptionPane.showMessageDialog(this, "Request denied.", "Request Denied", JOptionPane.INFORMATION_MESSAGE);
        }

        refreshAllData(); // Refresh all relevant tables
    }

    // --- Panel: Delete Student ---
    private JPanel createDeleteStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Delete Student Account", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST; formPanel.add(new JLabel("Select Student to Delete:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        deleteStudentComboBox = new JComboBox<>();
        applyBlackAndWhiteTheme(deleteStudentComboBox);
        formPanel.add(deleteStudentComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        deleteStudentButton = new JButton("Delete Student Permanently");
        formPanel.add(deleteStudentButton, gbc);

        panel.add(formPanel, BorderLayout.CENTER);

        deleteStudentButton.addActionListener(e -> deleteStudentAccount());

        return panel;
    }

    private void deleteStudentAccount() {
        String studentIdToDelete = (String) deleteStudentComboBox.getSelectedItem();
        if (studentIdToDelete == null || studentIdToDelete.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a student to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to permanently delete student '" + studentIdToDelete + "' and all associated data (enrollments, requests)?\nThis action cannot be undone.",
                "Confirm Student Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            // 1. Delete Student Data (from students.txt)
            Student student = studentDataManager.getStudentByUserId(studentIdToDelete);
            if (student != null) {
                // To "delete" from StudentDataManager, we need a method to remove from its internal list and re-save.
                // StudentDataManager currently only has updateStudent, getStudentByUserId, load, save.
                // Let's add a delete method to StudentDataManager.
                // Refactoring note: For simplicity, I will implement a quick delete in StudentDataManager.
                List<Student> allStudents = studentDataManager.loadStudents();
                boolean studentRemoved = allStudents.removeIf(s -> s.getUserId().equals(studentIdToDelete));
                if (studentRemoved) {
                    studentDataManager.saveStudents(allStudents);
                }
            }

            // 2. Delete User Account (from users.txt)
            boolean userRemoved = authenticator.deleteUser(studentIdToDelete);

            // 3. Delete associated Enrollments (from enrollments.txt)
            List<Enrollment> studentEnrollments = enrollmentManager.getEnrollmentsByStudent(studentIdToDelete);
            for (Enrollment enrollment : studentEnrollments) {
                enrollmentManager.deleteEnrollment(enrollment.getEnrollmentId()); // Deletes one by one
            }

            // 4. Delete associated Subject Change Requests (from requests.txt)
            List<SubjectChangeRequest> studentRequests = requestManager.loadRequests().stream()
                    .filter(req -> req.getStudentId().equals(studentIdToDelete))
                    .collect(Collectors.toList());
            for (SubjectChangeRequest req : studentRequests) {
                requestManager.deleteRequest(req.getRequestId()); // Deletes one by one
            }

            // Payment records are typically kept for financial history, so not deleting them here.

            if (userRemoved) { // Assuming user removal is the primary success indicator
                JOptionPane.showMessageDialog(this, "Student '" + studentIdToDelete + "' and associated data deleted successfully.", "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
                refreshAllData(); // Refresh all UI components that might display student data
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete student '" + studentIdToDelete + "'. User account not found or other error.", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    // --- Panel: Update Profile ---
    private JPanel createUpdateProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Update Own Profile (Receptionist)"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userIdLabel = new JLabel("User ID:");
        profileUserIdField = new JTextField(receptionistUser.getUserId());
        profileUserIdField.setEditable(false);
        applyBlackAndWhiteTheme(profileUserIdField);

        JLabel currentPasswordLabel = new JLabel("Current Password:");
        profileCurrentPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(profileCurrentPasswordField);

        JLabel newPasswordLabel = new JLabel("New Password:");
        profileNewPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(profileNewPasswordField);

        JLabel confirmNewPasswordLabel = new JLabel("Confirm New Password:");
        profileConfirmNewPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(profileConfirmNewPasswordField);

        profileUpdatePasswordButton = new JButton("Update Password");

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; panel.add(userIdLabel, gbc);
        gbc.gridx = 1; gbc.gridy = row++; panel.add(profileUserIdField, gbc);

        gbc.gridx = 0; gbc.gridy = row; panel.add(currentPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = row++; panel.add(profileCurrentPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = row; panel.add(newPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = row++; panel.add(profileNewPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = row; panel.add(confirmNewPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = row++; panel.add(profileConfirmNewPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2; panel.add(profileUpdatePasswordButton, gbc);

        profileUpdatePasswordButton.addActionListener(e -> updateOwnProfile());

        return panel;
    }

    private void updateOwnProfile() {
        String currentPass = new String(profileCurrentPasswordField.getPassword());
        String newPass = new String(profileNewPasswordField.getPassword());
        String confirmNewPass = new String(profileConfirmNewPasswordField.getPassword());

        if (!currentPass.equals(receptionistUser.getPassword())) {
            JOptionPane.showMessageDialog(this, "Current password incorrect.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (newPass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "New password cannot be empty.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!newPass.equals(confirmNewPass)) {
            JOptionPane.showMessageDialog(this, "New password and confirmation do not match.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (authenticator.updatePassword(receptionistUser.getUserId(), newPass)) {
            // IMPORTANT: Update the receptionistUser object in memory with the new password
            this.receptionistUser = authenticator.getUserById(receptionistUser.getUserId()); // Re-fetch the updated user

            JOptionPane.showMessageDialog(this, "Password updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            profileCurrentPasswordField.setText("");
            profileNewPasswordField.setText("");
            profileConfirmNewPasswordField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update password.", "Update Failed", JOptionPane.ERROR_MESSAGE);
        }
    }


    // --- Global Data Refresh Method ---
    private void refreshAllData() {
        // Refresh student data in various combo boxes
        List<Student> allStudents = studentDataManager.loadStudents();
        List<String> studentIds = allStudents.stream().map(User::getUserId).sorted().collect(Collectors.toList());

        // Register & Enroll Student (no student-specific data to refresh here, only subjects based on level)
        updateAvailableSubjectsList(); // Ensures subject list is current based on selected level

        // Manage Enrollments
        String currentSelectedManageEnrollStudent = (String) manageEnrollStudentComboBox.getSelectedItem();
        manageEnrollStudentComboBox.removeAllItems();
        studentIds.forEach(manageEnrollStudentComboBox::addItem);
        if (currentSelectedManageEnrollStudent != null && studentIds.contains(currentSelectedManageEnrollStudent)) {
            manageEnrollStudentComboBox.setSelectedItem(currentSelectedManageEnrollStudent);
        } else if (!studentIds.isEmpty()) {
            manageEnrollStudentComboBox.setSelectedIndex(0);
        } else {
            manageEnrollmentTableModel.setRowCount(0); // Clear table if no students
        }
        loadStudentEnrollments(); // Reload enrollments for the current student

        // Accept Payments
        String currentSelectedPaymentStudent = (String) paymentStudentComboBox.getSelectedItem();
        paymentStudentComboBox.removeAllItems();
        studentIds.forEach(paymentStudentComboBox::addItem);
        if (currentSelectedPaymentStudent != null && studentIds.contains(currentSelectedPaymentStudent)) {
            paymentStudentComboBox.setSelectedItem(currentSelectedPaymentStudent);
        } else if (!studentIds.isEmpty()) {
            paymentStudentComboBox.setSelectedIndex(0);
        }
        updatePaymentBalance(); // Update balance for the current student

        // Handle Subject Requests
        loadPendingRequests(); // Reload pending requests

        // Delete Student
        String currentSelectedDeleteStudent = (String) deleteStudentComboBox.getSelectedItem();
        deleteStudentComboBox.removeAllItems();
        studentIds.forEach(deleteStudentComboBox::addItem);
        if (currentSelectedDeleteStudent != null && studentIds.contains(currentSelectedDeleteStudent)) {
            deleteStudentComboBox.setSelectedItem(currentSelectedDeleteStudent);
        } else if (!studentIds.isEmpty()) {
            deleteStudentComboBox.setSelectedIndex(0);
        }

        // Update Profile (no dynamic data to reload, fields just display static user ID)
    }
}