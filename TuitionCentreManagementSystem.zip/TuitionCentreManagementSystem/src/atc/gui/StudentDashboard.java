package atc.gui;

import atc.data.ClassScheduleManager;
import atc.data.RequestManager;
import atc.data.StudentDataManager;
import atc.model.Student;
import atc.model.SubjectChangeRequest;
import atc.model.SubjectClass;
import atc.model.User;
import atc.auth.ClassManager; // New Import for ClassInfo
import atc.model.ClassInfo;    // New Import for ClassInfo
import atc.auth.AssignmentManager; // New Import for AssignmentManager
import atc.model.Assignment;   // New Import for Assignment

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;         // For file operations (download)
import java.io.IOException;    // For file operations (download)
import java.util.List;
import java.util.stream.Collectors;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional; // Add this line

public class StudentDashboard extends JFrame {
    private Student studentUser; // Cast User to Student for specific student data
    private JLabel welcomeLabel;

    // UI Components for various panels
    private JTabbedPane tabbedPane;

    // View Schedule Tab
    private JTable scheduleTable;
    private DefaultTableModel scheduleTableModel;

    // Subject Enrollment Request Tab
    private JComboBox<String> currentSubjectComboBox;
    private JComboBox<String> newSubjectComboBox;
    private JButton sendRequestButton;
    private JTable pendingRequestsTable;
    private DefaultTableModel pendingRequestsTableModel;
    private JButton deleteRequestButton;

    // Payment Status Tab
    private JLabel balanceDueLabel;

    // Update Profile Tab
    private JTextField nameField, icPassportField, emailField, contactNumberField, addressField;
    private JComboBox<String> levelComboBox;
    private JLabel currentSubjectsLabel;
    private JButton updateProfileButton;

    // NEW FEATURE: Assignment Management (Student View)
    private ClassManager classManager; // To get class details
    private AssignmentManager assignmentManager; // To manage assignments
    private JComboBox<ClassInfo> studentClassAssignmentComboBox; // To select class for assignments
    private JTable assignmentsTable;
    private DefaultTableModel assignmentsTableModel;

    public StudentDashboard(User user) {
        // Cast the generic User object to a Student object
        // We'll load the full student details from the file
        this.studentUser = StudentDataManager.getStudentByUserId(user.getUserId());
        if (this.studentUser == null) {
            JOptionPane.showMessageDialog(this, "Student data not found! Please contact admin.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            new LoginScreen(); // Redirect to login if student data isn't found
            dispose();
            return;
        }

        // NEW FEATURE: Initialize managers
        this.classManager = new ClassManager();
        this.assignmentManager = new AssignmentManager();

        setTitle("ATC Student Dashboard - Welcome, " + studentUser.getName());
        setSize(1000, 700); // Increased size for more content
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Black and White UI Settings ---
        getContentPane().setBackground(Color.WHITE);
        UIManager.put("Label.foreground", Color.BLACK);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.background", Color.BLACK);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("TabbedPane.background", Color.WHITE); // Tab background
        UIManager.put("TabbedPane.selectedBackground", Color.LIGHT_GRAY); // Selected tab
        UIManager.put("Table.background", Color.WHITE);
        UIManager.put("Table.foreground", Color.BLACK);
        UIManager.put("TableHeader.background", Color.BLACK);
        UIManager.put("TableHeader.foreground", Color.WHITE);
        UIManager.put("ComboBox.background", Color.WHITE);
        UIManager.put("ComboBox.foreground", Color.BLACK);
        UIManager.put("TextField.background", Color.WHITE);
        UIManager.put("TextField.foreground", Color.BLACK);
        UIManager.put("TextArea.background", Color.WHITE);
        UIManager.put("TextArea.foreground", Color.BLACK);
        UIManager.put("ScrollPane.background", Color.WHITE);
        UIManager.put("Viewport.background", Color.WHITE); // Background of JScrollPane's viewport


        initComponents();
        addListeners(); // This is mostly empty, but kept for structure
        setVisible(true);
        refreshData(); // Load initial data when dashboard opens
    }

    private void initComponents() {
        // Main panel with BorderLayout for overall layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // Welcome Panel at the top
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topPanel.setBackground(Color.WHITE);
        welcomeLabel = new JLabel(
                "<html><center><h2>Welcome to your Dashboard, " + studentUser.getName() +
                        "!</h2></center></html>",
                SwingConstants.CENTER
        );
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(welcomeLabel);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // JTabbedPane for different functionalities
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(Color.WHITE); // Apply theme to tabbed pane itself
        tabbedPane.setForeground(Color.BLACK); // Text color for tabs

        // Add individual feature panels as tabs
        tabbedPane.addTab("View Schedule", createViewSchedulePanel());
        tabbedPane.addTab("Subject Request", createSubjectRequestPanel());
        tabbedPane.addTab("Payment Status", createPaymentStatusPanel());
        // NEW FEATURE: Add Assignments tab
        tabbedPane.addTab("View Assignments", createViewAssignmentsPanel());
        tabbedPane.addTab("Update Profile", createUpdateProfilePanel());


        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Logout Button at the bottom right
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.WHITE);
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(StudentDashboard.this, "Are you sure you want to log out?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    new LoginScreen();
                    dispose();
                }
            }
        });
        bottomPanel.add(logoutButton);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void addListeners() {
        // Listeners are added within their respective panel creation methods
        // or through specific helper methods.
    }

    private JPanel createViewSchedulePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Your Class Schedule", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"Subject", "Level", "Tutor", "Schedule", "Charges (RM)"};
        scheduleTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        scheduleTable = new JTable(scheduleTableModel);
        scheduleTable.setFillsViewportHeight(true); // Table takes up full height of scroll pane
        scheduleTable.getTableHeader().setReorderingAllowed(false); // Prevent column reordering
        scheduleTable.getTableHeader().setBackground(UIManager.getColor("TableHeader.background"));
        scheduleTable.getTableHeader().setForeground(UIManager.getColor("TableHeader.foreground"));
        scheduleTable.setBackground(UIManager.getColor("Table.background"));
        scheduleTable.setForeground(UIManager.getColor("Table.foreground"));

        JScrollPane scrollPane = new JScrollPane(scheduleTable);
        scrollPane.setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);

        loadClassSchedule(); // Load data initially

        return panel;
    }

    private void loadClassSchedule() {
        scheduleTableModel.setRowCount(0); // Clear existing data

        // Load all classes from classes.txt using the ClassDataManager
        List<atc.model.CourseClass> allClasses = atc.data.ClassDataManager.loadClasses();

        // Filter classes for subjects the student is enrolled in and their level
        // Note: We are now using atc.model.CourseClass
        List<atc.model.CourseClass> studentClasses = allClasses.stream()
                .filter(cc -> studentUser.getEnrolledSubjects().contains(cc.getSubjectName()) &&
                        cc.getLevel().equalsIgnoreCase(studentUser.getLevel()))
                .collect(Collectors.toList());

        if (studentClasses.isEmpty()) {
            // If no classes found for the student, display a message
            scheduleTableModel.addRow(new Object[]{"No classes enrolled or schedule unavailable.", "", "", "", ""});
        } else {
            // Populate the table with the filtered student classes
            for (atc.model.CourseClass cc : studentClasses) {
                // Construct the schedule string from Day, Time, and Duration
                String scheduleString = String.format("%s, %s for %s",
                        cc.getDay(),
                        cc.getTime(),
                        cc.getDuration());

                scheduleTableModel.addRow(new Object[]{
                        cc.getSubjectName(), // Subject Name
                        cc.getLevel(),       // Level
                        cc.getTutorId(),     // Tutor ID (used as Tutor Name as per classes.txt)
                        scheduleString,      // Constructed Schedule
                        String.format("%.2f", cc.getFee()) // Class Fee (charges)
                });
            }
        }
    }


    private JPanel createSubjectRequestPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Subject Enrollment Change Request", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        // --- Request Form Panel ---
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createTitledBorder("Send New Request"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel currentSubLabel = new JLabel("Current Subject to Drop (Optional):");
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(currentSubLabel, gbc);

        currentSubjectComboBox = new JComboBox<>();
        currentSubjectComboBox.addItem("None"); // Option to only add a new subject
        // Populate with student's current enrolled subjects
        studentUser.getEnrolledSubjects().forEach(currentSubjectComboBox::addItem);
        gbc.gridx = 1; gbc.gridy = 0;
        formPanel.add(currentSubjectComboBox, gbc);

        JLabel newSubLabel = new JLabel("New Subject to Add (Optional):");
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(newSubLabel, gbc);

        newSubjectComboBox = new JComboBox<>();
        newSubjectComboBox.addItem("None"); // Option to only drop a subject
        // Populate with available subjects (excluding already enrolled ones)
        List<String> availableSubjects = ClassScheduleManager.loadClassSchedules().stream()
                .filter(sc -> sc.getLevel().equalsIgnoreCase(studentUser.getLevel()) &&
                        !studentUser.getEnrolledSubjects().contains(sc.getSubjectName()))
                .map(SubjectClass::getSubjectName)
                .distinct()
                .collect(Collectors.toList());
        availableSubjects.forEach(newSubjectComboBox::addItem);

        gbc.gridx = 1; gbc.gridy = 1;
        formPanel.add(newSubjectComboBox, gbc);

        sendRequestButton = new JButton("Send Request");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(sendRequestButton, gbc);

        sendRequestButton.addActionListener(e -> sendSubjectChangeRequest());

        panel.add(formPanel, BorderLayout.NORTH);

        // --- Pending Requests Table ---
        JPanel requestsPanel = new JPanel(new BorderLayout(5, 5));
        requestsPanel.setBackground(Color.WHITE);
        requestsPanel.setBorder(BorderFactory.createTitledBorder("Your Pending Requests"));

        String[] requestColumnNames = {"Request ID", "Current Subject", "New Subject", "Date Sent", "Status"};
        pendingRequestsTableModel = new DefaultTableModel(requestColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        pendingRequestsTable = new JTable(pendingRequestsTableModel);
        pendingRequestsTable.setFillsViewportHeight(true);
        pendingRequestsTable.getTableHeader().setReorderingAllowed(false);
        pendingRequestsTable.getTableHeader().setBackground(UIManager.getColor("TableHeader.background"));
        pendingRequestsTable.getTableHeader().setForeground(UIManager.getColor("TableHeader.foreground"));
        pendingRequestsTable.setBackground(UIManager.getColor("Table.background"));
        pendingRequestsTable.setForeground(UIManager.getColor("Table.foreground"));

        JScrollPane requestScrollPane = new JScrollPane(pendingRequestsTable);
        requestScrollPane.setBackground(Color.WHITE);
        requestsPanel.add(requestScrollPane, BorderLayout.CENTER);

        deleteRequestButton = new JButton("Delete Selected Request");
        JPanel deleteButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        deleteButtonPanel.setBackground(Color.WHITE);
        deleteButtonPanel.add(deleteRequestButton);
        requestsPanel.add(deleteButtonPanel, BorderLayout.SOUTH);

        deleteRequestButton.addActionListener(e -> deleteSelectedRequest());

        panel.add(requestsPanel, BorderLayout.CENTER);

        loadPendingRequests(); // Load initial data
        return panel;
    }

    private void sendSubjectChangeRequest() {
        String currentSub = (String) currentSubjectComboBox.getSelectedItem();
        String newSub = (String) newSubjectComboBox.getSelectedItem();

        if ("None".equals(currentSub) && "None".equals(newSub)) {
            JOptionPane.showMessageDialog(this, "Please select at least one subject to drop or add.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Basic validation: Cannot drop a subject not currently enrolled in
        if (!"None".equals(currentSub) && !studentUser.getEnrolledSubjects().contains(currentSub)) {
            JOptionPane.showMessageDialog(this, "You are not currently enrolled in '" + currentSub + "'.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Basic validation: Cannot add a subject already enrolled in
        if (!"None".equals(newSub) && studentUser.getEnrolledSubjects().contains(newSub)) {
            JOptionPane.showMessageDialog(this, "You are already enrolled in '" + newSub + "'.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Check for duplicate pending requests (optional, but good practice)
        boolean duplicate = studentUser.getPendingRequests().stream().anyMatch(req ->
                (req.getCurrentSubject() != null && req.getCurrentSubject().equals(currentSub) || req.getCurrentSubject() == null && "None".equals(currentSub)) &&
                        (req.getNewSubject() != null && req.getNewSubject().equals(newSub) || req.getNewSubject() == null && "None".equals(newSub)) &&
                        req.getStatus().equalsIgnoreCase("Pending")
        );
        if (duplicate) {
            JOptionPane.showMessageDialog(this, "A similar pending request already exists.", "Duplicate Request", JOptionPane.WARNING_MESSAGE);
            return;
        }


        SubjectChangeRequest newRequest = new SubjectChangeRequest(
                studentUser.getUserId(),
                "None".equals(currentSub) ? null : currentSub,
                "None".equals(newSub) ? null : newSub
        );

        RequestManager.addRequest(newRequest); // Save to file
        studentUser.addPendingRequest(newRequest); // Update student's local list
        StudentDataManager.updateStudent(studentUser); // Save updated student (just in case pending requests need to be persisted directly)

        JOptionPane.showMessageDialog(this, "Your request has been sent to the receptionist.", "Request Sent", JOptionPane.INFORMATION_MESSAGE);
        loadPendingRequests(); // Refresh the table
    }


    private void loadPendingRequests() {
        pendingRequestsTableModel.setRowCount(0); // Clear existing data
        List<SubjectChangeRequest> requests = RequestManager.getPendingRequestsByStudentId(studentUser.getUserId());
        studentUser.setPendingRequests(requests); // Update the student's internal list of pending requests

        if (requests.isEmpty()) {
            pendingRequestsTableModel.addRow(new Object[]{"No pending requests.", "", "", "", ""});
        } else {
            for (SubjectChangeRequest req : requests) {
                pendingRequestsTableModel.addRow(new Object[]{
                        req.getRequestId(),
                        req.getCurrentSubject() != null ? req.getCurrentSubject() : "N/A (Adding)",
                        req.getNewSubject() != null ? req.getNewSubject() : "N/A (Dropping)",
                        req.getRequestDate(),
                        req.getStatus()
                });
            }
        }
    }

    private void deleteSelectedRequest() {
        int selectedRow = pendingRequestsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Get the request ID from the table model
        String requestId = (String) pendingRequestsTableModel.getValueAt(selectedRow, 0);

        // Confirm deletion
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this request?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            RequestManager.deleteRequest(requestId); // Delete from file
            // Remove from student's local list as well (filter out the deleted one)
            studentUser.setPendingRequests(
                    studentUser.getPendingRequests().stream()
                            .filter(req -> !req.getRequestId().equals(requestId))
                            .collect(Collectors.toList())
            );
            StudentDataManager.updateStudent(studentUser); // Save updated student data (if pending requests were part of it)

            JOptionPane.showMessageDialog(this, "Request deleted successfully.", "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
            loadPendingRequests(); // Refresh the table
        }
    }


    private JPanel createPaymentStatusPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel titleLabel = new JLabel("Your Payment Status", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);

        // Spacer
        gbc.gridy = 1; gbc.weighty = 0.1;
        panel.add(new JPanel() {{ setOpaque(false); }}, gbc); // Invisible panel for spacing

        JLabel balancePrompt = new JLabel("Total Balance Due:");
        balancePrompt.setFont(new Font("Arial", Font.PLAIN, 18));
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(balancePrompt, gbc);

        balanceDueLabel = new JLabel(String.format("RM %.2f", studentUser.getBalanceDue()));
        balanceDueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        balanceDueLabel.setForeground(studentUser.getBalanceDue() > 0 ? Color.RED : Color.BLUE); // Red if due, Blue if 0
        gbc.gridx = 1; gbc.gridy = 2; gbc.anchor = GridBagConstraints.WEST;
        panel.add(balanceDueLabel, gbc);

        // Information/Instruction message
        JLabel infoLabel = new JLabel("<html><i>Please contact the receptionist for detailed payment history or to make a payment.</i></html>", SwingConstants.CENTER);
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(infoLabel, gbc);

        return panel;
    }

    private void updatePaymentStatusDisplay() {
        balanceDueLabel.setText(String.format("RM %.2f", studentUser.getBalanceDue()));
        balanceDueLabel.setForeground(studentUser.getBalanceDue() > 0 ? Color.RED : Color.BLUE);
    }

    // NEW FEATURE: Create View Assignments Panel
    private JPanel createViewAssignmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("View Class Assignments", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        // Class selection panel
        JPanel classSelectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        classSelectionPanel.setBackground(Color.WHITE);
        classSelectionPanel.add(new JLabel("Select Class:"));
        studentClassAssignmentComboBox = new JComboBox<>();
        studentClassAssignmentComboBox.setBackground(Color.WHITE);
        studentClassAssignmentComboBox.setForeground(Color.BLACK);
        classSelectionPanel.add(studentClassAssignmentComboBox);
        panel.add(classSelectionPanel, BorderLayout.NORTH);

        // Assignments table
        String[] columnNames = {"Assignment ID", "Class", "Title", "Description", "Uploaded By", "Upload Date", "File Name"};
        assignmentsTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make cells non-editable
            }
        };
        assignmentsTable = new JTable(assignmentsTableModel);
        assignmentsTable.setFillsViewportHeight(true);
        assignmentsTable.getTableHeader().setReorderingAllowed(false);
        assignmentsTable.getTableHeader().setBackground(UIManager.getColor("TableHeader.background"));
        assignmentsTable.getTableHeader().setForeground(UIManager.getColor("TableHeader.foreground"));
        assignmentsTable.setBackground(UIManager.getColor("Table.background"));
        assignmentsTable.setForeground(UIManager.getColor("Table.foreground"));

        JScrollPane scrollPane = new JScrollPane(assignmentsTable);
        scrollPane.setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Download button
        JButton downloadButton = new JButton("Download Selected Assignment");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(downloadButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Populate class combo box for assignments
        loadClassesForAssignments();

        // Listener for class selection
        studentClassAssignmentComboBox.addActionListener(e -> loadAssignmentsForSelectedClass());

        // Listener for download button
        downloadButton.addActionListener(e -> downloadSelectedAssignment());

        // Initial load of assignments if a class is already selected
        loadAssignmentsForSelectedClass();

        return panel;
    }

    // NEW FEATURE: Method to populate class combo box for assignments
    private void loadClassesForAssignments() {
        studentClassAssignmentComboBox.removeAllItems();
        studentClassAssignmentComboBox.addItem(null); // Add a "Select a class" option or similar

        // Get all classes this student is enrolled in
        List<ClassInfo> enrolledClasses = studentUser.getEnrolledSubjects().stream()
                .flatMap(subjectName -> classManager.getClassesBySubjectAndLevel(subjectName, studentUser.getLevel()).stream())
                .distinct()
                .collect(Collectors.toList());

        for (ClassInfo classInfo : enrolledClasses) {
            studentClassAssignmentComboBox.addItem(classInfo);
        }
    }

    // NEW FEATURE: Method to load assignments for the selected class
    private void loadAssignmentsForSelectedClass() {
        assignmentsTableModel.setRowCount(0); // Clear existing data

        ClassInfo selectedClass = (ClassInfo) studentClassAssignmentComboBox.getSelectedItem();

        if (selectedClass == null) {
            assignmentsTableModel.addRow(new Object[]{"Please select a class.", "", "", "", "", "", ""});
            return;
        }

        List<Assignment> assignments = assignmentManager.getAssignmentsByClassId(selectedClass.getClassId());

        if (assignments.isEmpty()) {
            assignmentsTableModel.addRow(new Object[]{"No assignments found for this class.", "", "", "", "", "", ""});
        } else {
            for (Assignment assign : assignments) {
                Path p = Paths.get(assign.getFilePath());
                assignmentsTableModel.addRow(new Object[]{
                        assign.getAssignmentId(),
                        selectedClass.getSubject() + " (" + selectedClass.getLevel() + ")", // Display class name
                        assign.getTitle(),
                        assign.getDescription(),
                        assign.getTutorId(), // Uploader (Tutor ID)
                        assign.getUploadDate(),
                        p.getFileName().toString() // File Name
                });
            }
        }
    }

    // NEW FEATURE: Method to handle downloading a selected assignment
    private void downloadSelectedAssignment() {
        int selectedRow = assignmentsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an assignment to download.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String assignmentId = (String) assignmentsTableModel.getValueAt(selectedRow, 0);
        Optional<Assignment> selectedAssignmentOpt = assignmentManager.getAssignmentById(assignmentId);

        if (selectedAssignmentOpt.isPresent()) {
            Assignment assignment = selectedAssignmentOpt.get();
            File assignmentFile = new File(assignment.getFilePath());

            if (assignmentFile.exists()) {
                // Open the file using the default system application
                try {
                    Desktop.getDesktop().open(assignmentFile);
                    JOptionPane.showMessageDialog(this, "Opening assignment: " + assignmentFile.getName(), "File Opened", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Could not open file. Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                } catch (UnsupportedOperationException ex) {
                    JOptionPane.showMessageDialog(this, "Desktop operations not supported on this system.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Assignment file not found on server: " + assignmentFile.getName(), "File Missing", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selected assignment not found in records.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private JPanel createUpdateProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Update Your Profile", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);

        // Labels and Text Fields for profile details
        int row = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;

        panel.add(new JLabel("User ID:"), gbc);
        JTextField userIdDisplayField = new JTextField(studentUser.getUserId());
        userIdDisplayField.setEditable(false); // User ID cannot be changed
        userIdDisplayField.setBackground(Color.LIGHT_GRAY);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(userIdDisplayField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Name:"), gbc);
        nameField = new JTextField(studentUser.getName(), 20);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("IC/Passport:"), gbc);
        icPassportField = new JTextField(studentUser.getIcPassport(), 20);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(icPassportField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Email:"), gbc);
        emailField = new JTextField(studentUser.getEmail(), 20);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Contact Number:"), gbc);
        contactNumberField = new JTextField(studentUser.getContactNumber(), 20);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(contactNumberField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Address:"), gbc);
        addressField = new JTextField(studentUser.getAddress(), 20);
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(addressField, gbc);

        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Level (Form):"), gbc);
        String[] levels = {"Form 1", "Form 2", "Form 3", "Form 4", "Form 5"};
        levelComboBox = new JComboBox<>(levels);
        levelComboBox.setSelectedItem(studentUser.getLevel());
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        panel.add(levelComboBox, gbc);

        // Display current subjects (read-only for student on this panel)
        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Enrolled Subjects:"), gbc);
        currentSubjectsLabel = new JLabel("<html>" + String.join("<br>", studentUser.getEnrolledSubjects()) + "</html>");
        currentSubjectsLabel.setVerticalAlignment(SwingConstants.TOP); // Align text to top if multiple lines
        gbc.gridx = 1; gbc.gridy = row++; gbc.anchor = GridBagConstraints.WEST;
        gbc.weighty = 0.5; // Give this row some vertical space
        panel.add(currentSubjectsLabel, gbc);
        gbc.weighty = 0; // Reset weight

        updateProfileButton = new JButton("Update Profile");
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(updateProfileButton, gbc);

        updateProfileButton.addActionListener(e -> updateStudentProfile());

        return panel;
    }

    private void updateStudentProfile() {
        String newName = nameField.getText().trim();
        String newIcPassport = icPassportField.getText().trim();
        String newEmail = emailField.getText().trim();
        String newContactNumber = contactNumberField.getText().trim();
        String newAddress = addressField.getText().trim();
        String newLevel = (String) levelComboBox.getSelectedItem();

        // Basic validation (can be more robust with regex if needed)
        if (newName.isEmpty() || newIcPassport.isEmpty() || newEmail.isEmpty() ||
                newContactNumber.isEmpty() || newAddress.isEmpty() || newLevel == null) {
            JOptionPane.showMessageDialog(this, "Please fill in all profile fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Update the studentUser object
        studentUser.setName(newName);
        studentUser.setIcPassport(newIcPassport);
        studentUser.setEmail(newEmail);
        studentUser.setContactNumber(newContactNumber);
        studentUser.setAddress(newAddress);
        studentUser.setLevel(newLevel);

        // Save the updated student data back to the file
        StudentDataManager.updateStudent(studentUser);

        JOptionPane.showMessageDialog(this, "Profile updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        // Refresh display components that show updated data (like welcome message, enrolled subjects)
        refreshData();
    }

    // Call this method to refresh all dynamic data displays
    private void refreshData() {
        // Reload the student data from file to ensure it's fresh (especially after updates by other roles)
        studentUser = StudentDataManager.getStudentByUserId(studentUser.getUserId());
        if (studentUser == null) {
            // This should ideally not happen if student data exists, but as a safeguard
            JOptionPane.showMessageDialog(this, "Student data refresh failed. Please re-login.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            new LoginScreen();
            dispose();
            return;
        }

        welcomeLabel.setText("<html><center><h2>Welcome to your Dashboard, " + studentUser.getName() +
                "!</h2></center></html>");
        loadClassSchedule();
        loadPendingRequests();
        updatePaymentStatusDisplay();

        // NEW FEATURE: Refresh assignments related data
        loadClassesForAssignments(); // Re-populate the class combo box
        loadAssignmentsForSelectedClass(); // Re-load assignments for the currently selected class

        // Update profile fields in case they were updated from elsewhere (though unlikely for student's own dashboard)
        // or just to ensure UI reflects current state if student updated it.
        nameField.setText(studentUser.getName());
        icPassportField.setText(studentUser.getIcPassport());
        emailField.setText(studentUser.getEmail());
        contactNumberField.setText(studentUser.getContactNumber());
        addressField.setText(studentUser.getAddress());
        levelComboBox.setSelectedItem(studentUser.getLevel());
        currentSubjectsLabel.setText("<html>" + String.join("<br>", studentUser.getEnrolledSubjects()) + "</html>");

        // Re-populate subject combo boxes in request panel as subjects might change
        currentSubjectComboBox.removeAllItems();
        currentSubjectComboBox.addItem("None");
        studentUser.getEnrolledSubjects().forEach(currentSubjectComboBox::addItem);

        newSubjectComboBox.removeAllItems();
        newSubjectComboBox.addItem("None");
        List<String> availableSubjects = ClassScheduleManager.loadClassSchedules().stream()
                .filter(sc -> sc.getLevel().equalsIgnoreCase(studentUser.getLevel()) &&
                        !studentUser.getEnrolledSubjects().contains(sc.getSubjectName()))
                .map(SubjectClass::getSubjectName)
                .distinct()
                .collect(Collectors.toList());
        availableSubjects.forEach(newSubjectComboBox::addItem);
    }
}