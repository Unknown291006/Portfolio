package atc.gui;

import atc.auth.Authenticator;
import atc.auth.ClassManager;
import atc.auth.EnrollmentManager;
import atc.auth.TutorDataManager;
import atc.auth.AssignmentManager; // New import
import atc.model.ClassInfo;
import atc.model.Enrollment;
import atc.model.Tutor;
import atc.model.User;
import atc.model.Assignment; // New import

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;               // For JFileChooser
import java.nio.file.Path;         // For file paths
import java.nio.file.Paths;        // For file paths
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.LocalDate;        // For assignment upload date
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.Vector;
import java.util.stream.Collectors;

public class TutorDashboard extends JFrame {
    private Tutor tutorUser;
    private Authenticator authenticator;
    private ClassManager classManager;
    private EnrollmentManager enrollmentManager;
    private TutorDataManager tutorDataManager;
    private AssignmentManager assignmentManager; // New Manager

    // Common UI elements
    private JTabbedPane tabbedPane;
    private JButton logoutButton;

    // Data for dropdowns (hardcoded for now, will be filtered)
    private final String[] ALL_LEVELS = {"Secondary 1", "Secondary 2", "Secondary 3", "Secondary 4", "Secondary 5"};
    private final String[] ALL_SUBJECTS = {"Mathematics", "Science", "English", "Physics", "Biology", "AddMath"};
    private final String[] DURATIONS = {"30 mins", "45 mins", "1 hour", "1.5 hours", "2 hours"};
    private final DayOfWeek[] DAYS_OF_WEEK = DayOfWeek.values();

    public TutorDashboard(User tutorBasicUser) {
        this.authenticator = new Authenticator();
        this.classManager = new ClassManager();
        this.enrollmentManager = new EnrollmentManager();
        this.tutorDataManager = new TutorDataManager();
        this.assignmentManager = new AssignmentManager(); // Initialize AssignmentManager

        // Fetch the detailed Tutor object including assigned subjects and levels
        Tutor detailedTutor = tutorDataManager.getTutorById(tutorBasicUser.getUserId());
        if (detailedTutor == null) {
            System.err.println("Detailed tutor data not found for " + tutorBasicUser.getUserId() + ". Creating basic tutor object.");
            this.tutorUser = new Tutor(tutorBasicUser.getUserId(), tutorBasicUser.getPassword());
        } else {
            this.tutorUser = detailedTutor;
        }

        setTitle("ATC Tutor Dashboard - Welcome, " + tutorUser.getUserId());
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        applyBlackAndWhiteTheme(this);

        createComponents();
        addListeners();
        setVisible(true);
    }

    private void applyBlackAndWhiteTheme(Component component) {
        component.setBackground(Color.WHITE);

        if (component instanceof JComponent) {
            JComponent jc = (JComponent) component;
            jc.setForeground(Color.BLACK);

            if (jc instanceof JPanel || jc instanceof JTabbedPane || jc instanceof JScrollPane || jc instanceof JViewport) {
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JLabel || jc instanceof JComboBox || jc instanceof JList || jc instanceof JMenuItem || jc instanceof JMenu) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JTextField || jc instanceof JPasswordField || jc instanceof JTextArea) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            }
            if (jc instanceof JButton) {
                jc.setForeground(Color.WHITE);
                jc.setBackground(Color.BLACK);
                Border buttonBorder = BorderFactory.createLineBorder(Color.BLACK);
                jc.setBorder(buttonBorder);
            }
            if (jc instanceof JTable) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                JTable table = (JTable) jc;
                if (table.getTableHeader() != null) {
                    table.getTableHeader().setBackground(Color.BLACK);
                    table.getTableHeader().setForeground(Color.WHITE);
                }
            }
        }
        if (component instanceof JMenuBar) {
            component.setBackground(Color.WHITE);
            component.setForeground(Color.BLACK);
        }

        if (component instanceof Container) {
            for (Component child : ((Container) component).getComponents()) {
                applyBlackAndWhiteTheme(child);
            }
        }
    }

    private void createComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(mainPanel);

        JPanel topPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(topPanel);
        JLabel titleLabel = new JLabel("Tutor Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 12));
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(logoutPanel);
        logoutPanel.add(logoutButton);
        topPanel.add(logoutPanel, BorderLayout.EAST);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        applyBlackAndWhiteTheme(tabbedPane);
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));

        tabbedPane.addTab("Manage Classes", createManageClassesPanel());
        tabbedPane.addTab("View Enrolled Students", createViewEnrolledStudentsPanel());
        tabbedPane.addTab("Manage Assignments", createManageAssignmentsPanel()); // NEW TAB
        tabbedPane.addTab("Update Profile", createUpdateProfilePanel());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        add(mainPanel);
    }

    private void addListeners() {
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new LoginScreen();
                dispose();
            }
        });
    }

    // --- Panel: Manage Classes (MODIFIED) ---
    private JPanel createManageClassesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        // Input/Add/Update Class Panel
        JPanel inputPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(inputPanel);
        inputPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Class Information"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField classIdField = new JTextField(10);
        classIdField.setEditable(false);
        classIdField.setText("Auto-generated");

        // Populate combo boxes with only assigned subjects and levels
        // Use Vector for JComboBox to handle potential empty lists gracefully
        JComboBox<String> subjectComboBox = new JComboBox<>(new Vector<>(tutorUser.getAssignedSubjects()));
        JComboBox<String> levelComboBox = new JComboBox<>(new Vector<>(tutorUser.getAssignedLevels()));

        JTextField chargesField = new JTextField(10);
        JComboBox<DayOfWeek> scheduleDayComboBox = new JComboBox<>(DAYS_OF_WEEK);
        JTextField scheduleTimeField = new JTextField("HH:MM", 8);
        JComboBox<String> durationComboBox = new JComboBox<>(DURATIONS);

        JButton addButton = new JButton("Add Class");
        JButton updateButton = new JButton("Update Class");
        JButton clearButton = new JButton("Clear Fields");

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("Class ID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(classIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("Subject:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(subjectComboBox, gbc);
        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(new JLabel("Level:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; inputPanel.add(levelComboBox, gbc);
        gbc.gridx = 0; gbc.gridy = 3; inputPanel.add(new JLabel("Charges:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3; inputPanel.add(chargesField, gbc);
        gbc.gridx = 0; gbc.gridy = 4; inputPanel.add(new JLabel("Schedule Day:"), gbc);
        gbc.gridx = 1; gbc.gridy = 4; inputPanel.add(scheduleDayComboBox, gbc);
        gbc.gridx = 0; gbc.gridy = 5; inputPanel.add(new JLabel("Schedule Time (HH:MM):"), gbc);
        gbc.gridx = 1; gbc.gridy = 5; inputPanel.add(scheduleTimeField, gbc);
        gbc.gridx = 0; gbc.gridy = 6; inputPanel.add(new JLabel("Duration:"), gbc);
        gbc.gridx = 1; gbc.gridy = 6; inputPanel.add(durationComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 1; inputPanel.add(addButton, gbc);
        gbc.gridx = 1; gbc.gridy = 7; gbc.gridwidth = 1; inputPanel.add(updateButton, gbc);
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2; inputPanel.add(clearButton, gbc);


        // Table to display classes
        JPanel viewDeletePanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(viewDeletePanel);
        viewDeletePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "My Classes"));

        String[] columnNames = {"Class ID", "Subject", "Level", "Charges", "Days", "Time", "Duration"};
        DefaultTableModel classTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable classTable = new JTable(classTableModel);
        applyBlackAndWhiteTheme(classTable);
        classTable.getTableHeader().setBackground(Color.BLACK);
        classTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(classTable);
        applyBlackAndWhiteTheme(scrollPane);

        JButton deleteButton = new JButton("Delete Selected Class");

        viewDeletePanel.add(scrollPane, BorderLayout.CENTER);
        JPanel deleteButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(deleteButtonPanel);
        deleteButtonPanel.add(deleteButton);
        viewDeletePanel.add(deleteButtonPanel, BorderLayout.SOUTH);

        // --- Helper to refresh class table ---
        Runnable refreshClassTable = () -> {
            classTableModel.setRowCount(0);
            List<ClassInfo> myClasses = classManager.getClassesByTutor(tutorUser.getUserId());
            for (ClassInfo ci : myClasses) {
                String daysStr = ci.getScheduleDays().stream()
                        .map(DayOfWeek::name)
                        .collect(Collectors.joining(", "));
                classTableModel.addRow(new Object[]{
                        ci.getClassId(), ci.getSubject(), ci.getLevel(),
                        String.format("%.2f", ci.getCharges()), daysStr,
                        ci.getScheduleTime().toString(), ci.getDuration()
                });
            }
        };
        refreshClassTable.run();

        // --- Listeners ---
        addButton.addActionListener(e -> {
            try {
                String classId = "CLS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
                String subject = (String) subjectComboBox.getSelectedItem();
                String level = (String) levelComboBox.getSelectedItem();
                double charges = Double.parseDouble(chargesField.getText().trim());
                List<DayOfWeek> scheduleDays = Arrays.asList((DayOfWeek) scheduleDayComboBox.getSelectedItem());
                LocalTime scheduleTime = LocalTime.parse(scheduleTimeField.getText().trim());
                String duration = (String) durationComboBox.getSelectedItem();

                if (subject == null || level == null || duration == null || scheduleTimeField.getText().trim().isEmpty() || chargesField.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill all class fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // *** Validation: Check if tutor is assigned to selected subject and level ***
                if (!tutorUser.getAssignedSubjects().contains(subject)) {
                    JOptionPane.showMessageDialog(this, "You are not assigned to teach the subject: " + subject, "Assignment Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!tutorUser.getAssignedLevels().contains(level)) {
                    JOptionPane.showMessageDialog(this, "You are not assigned to teach at the level: " + level, "Assignment Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                ClassInfo newClass = new ClassInfo(classId, tutorUser.getUserId(), subject, level, charges, scheduleDays, scheduleTime, duration);
                if (classManager.addClass(newClass)) {
                    JOptionPane.showMessageDialog(this, "Class added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshClassTable.run();
                    clearButton.doClick();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add class. Class ID might already exist.", "Add Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid charges amount. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Invalid time format. Please use HH:MM (e.g., 14:00).", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        updateButton.addActionListener(e -> {
            int selectedRow = classTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a class from the table to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                String classId = (String) classTableModel.getValueAt(selectedRow, 0);
                String subject = (String) subjectComboBox.getSelectedItem();
                String level = (String) levelComboBox.getSelectedItem();
                double charges = Double.parseDouble(chargesField.getText().trim());
                List<DayOfWeek> scheduleDays = Arrays.asList((DayOfWeek) scheduleDayComboBox.getSelectedItem());
                LocalTime scheduleTime = LocalTime.parse(scheduleTimeField.getText().trim());
                String duration = (String) durationComboBox.getSelectedItem();

                if (subject == null || level == null || duration == null || scheduleTimeField.getText().trim().isEmpty() || chargesField.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill all class fields for update.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // *** Validation: Check if tutor is assigned to selected subject and level ***
                if (!tutorUser.getAssignedSubjects().contains(subject)) {
                    JOptionPane.showMessageDialog(this, "You are not assigned to teach the subject: " + subject, "Assignment Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!tutorUser.getAssignedLevels().contains(level)) {
                    JOptionPane.showMessageDialog(this, "You are not assigned to teach at the level: " + level, "Assignment Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                ClassInfo updatedClass = new ClassInfo(classId, tutorUser.getUserId(), subject, level, charges, scheduleDays, scheduleTime, duration);
                if (classManager.updateClass(updatedClass)) {
                    JOptionPane.showMessageDialog(this, "Class updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshClassTable.run();
                    clearButton.doClick();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update class. Class not found.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid charges amount. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Invalid time format. Please use HH:MM (e.g., 14:00).", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = classTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a class to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String classIdToDelete = (String) classTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete class ID: " + classIdToDelete + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (classManager.deleteClass(classIdToDelete)) {
                    JOptionPane.showMessageDialog(this, "Class " + classIdToDelete + " deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    // You might also want to remove associated enrollments here
                    enrollmentManager.deleteEnrollmentsByClassId(classIdToDelete);
                    // Also delete any assignments associated with this class
                    List<Assignment> assignmentsToDelete = assignmentManager.getAssignmentsByClassId(classIdToDelete);
                    for (Assignment assign : assignmentsToDelete) {
                        assignmentManager.deleteAssignment(assign.getAssignmentId()); // This also deletes the file
                    }
                    refreshClassTable.run();
                    clearButton.doClick();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete class " + classIdToDelete + ".", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        clearButton.addActionListener(e -> {
            classIdField.setText("Auto-generated");
            // Set combo boxes to default if not empty, otherwise keep as is
            if (subjectComboBox.getItemCount() > 0) subjectComboBox.setSelectedIndex(0);
            if (levelComboBox.getItemCount() > 0) levelComboBox.setSelectedIndex(0);
            chargesField.setText("");
            scheduleDayComboBox.setSelectedIndex(0);
            scheduleTimeField.setText("HH:MM");
            durationComboBox.setSelectedIndex(0);
            classTable.clearSelection();
        });

        // Populate fields when a row is selected
        classTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && classTable.getSelectedRow() != -1) {
                int selectedRow = classTable.getSelectedRow();
                classIdField.setText((String) classTableModel.getValueAt(selectedRow, 0));
                subjectComboBox.setSelectedItem((String) classTableModel.getValueAt(selectedRow, 1));
                levelComboBox.setSelectedItem((String) classTableModel.getValueAt(selectedRow, 2));
                chargesField.setText(String.valueOf(classTableModel.getValueAt(selectedRow, 3)));
                String daysStr = (String) classTableModel.getValueAt(selectedRow, 4);
                List<DayOfWeek> daysInTable = Arrays.stream(daysStr.split(", "))
                        .map(DayOfWeek::valueOf)
                        .collect(Collectors.toList());
                if (!daysInTable.isEmpty()) {
                    scheduleDayComboBox.setSelectedItem(daysInTable.get(0));
                } else {
                    scheduleDayComboBox.setSelectedIndex(0);
                }
                scheduleTimeField.setText((String) classTableModel.getValueAt(selectedRow, 5));
                durationComboBox.setSelectedItem((String) classTableModel.getValueAt(selectedRow, 6));
            }
        });

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(viewDeletePanel, BorderLayout.CENTER);
        return panel;
    }

    // --- Panel: View Enrolled Students ---
    private JPanel createViewEnrolledStudentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        applyBlackAndWhiteTheme(topControls);
        JLabel selectClassLabel = new JLabel("Select Your Class:");
        JComboBox<ClassInfo> classSelectionComboBox = new JComboBox<>();
        applyBlackAndWhiteTheme(classSelectionComboBox);

        topControls.add(selectClassLabel);
        topControls.add(classSelectionComboBox);
        panel.add(topControls, BorderLayout.NORTH);

        String[] columnNames = {"Enrollment ID", "Student ID", "Class ID", "Enrollment Date"};
        DefaultTableModel studentEnrollmentTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable studentEnrollmentTable = new JTable(studentEnrollmentTableModel);
        applyBlackAndWhiteTheme(studentEnrollmentTable);
        studentEnrollmentTable.getTableHeader().setBackground(Color.BLACK);
        studentEnrollmentTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(studentEnrollmentTable);
        applyBlackAndWhiteTheme(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        List<ClassInfo> myClasses = classManager.getClassesByTutor(tutorUser.getUserId());
        for (ClassInfo ci : myClasses) {
            classSelectionComboBox.addItem(ci);
        }

        ActionListener classSelectionListener = e -> {
            studentEnrollmentTableModel.setRowCount(0);
            ClassInfo selectedClass = (ClassInfo) classSelectionComboBox.getSelectedItem();
            if (selectedClass != null) {
                List<Enrollment> enrollmentsInClass = enrollmentManager.getEnrollmentsByClass(selectedClass.getClassId());
                for (Enrollment en : enrollmentsInClass) {
                    studentEnrollmentTableModel.addRow(new Object[]{
                            en.getEnrollmentId(), en.getStudentId(), en.getClassId(), en.getEnrollmentDate()
                    });
                }
            }
        };
        classSelectionComboBox.addActionListener(classSelectionListener);

        if (classSelectionComboBox.getSelectedItem() != null) {
            classSelectionListener.actionPerformed(null);
        } else {
            studentEnrollmentTableModel.setRowCount(0);
        }

        return panel;
    }

    // --- Panel: Manage Assignments (NEW) ---
    private JPanel createManageAssignmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        // Input/Upload Assignment Panel
        JPanel inputPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(inputPanel);
        inputPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Upload New Assignment"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel classLabel = new JLabel("Select Class:");
        JComboBox<ClassInfo> classForAssignmentComboBox = new JComboBox<>();
        applyBlackAndWhiteTheme(classForAssignmentComboBox); // Apply theme to combo box

        // Populate with classes taught by this tutor
        List<ClassInfo> myClasses = classManager.getClassesByTutor(tutorUser.getUserId());
        for (ClassInfo ci : myClasses) {
            classForAssignmentComboBox.addItem(ci);
        }

        JLabel titleLabel = new JLabel("Assignment Title:");
        JTextField titleField = new JTextField(25);
        applyBlackAndWhiteTheme(titleField); // Apply theme

        JLabel descriptionLabel = new JLabel("Description:");
        JTextArea descriptionArea = new JTextArea(5, 25);
        JScrollPane descriptionScrollPane = new JScrollPane(descriptionArea);
        applyBlackAndWhiteTheme(descriptionArea);
        applyBlackAndWhiteTheme(descriptionScrollPane); // Apply theme to scroll pane holding textarea

        JLabel fileLabel = new JLabel("Select File:");
        JTextField filePathField = new JTextField(20);
        filePathField.setEditable(false);
        applyBlackAndWhiteTheme(filePathField); // Apply theme
        JButton browseButton = new JButton("Browse...");

        JButton uploadButton = new JButton("Upload Assignment");
        JButton clearAssignmentFieldsButton = new JButton("Clear Fields");

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(classLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(classForAssignmentComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(titleLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(titleField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(descriptionLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; inputPanel.add(descriptionScrollPane, gbc);

        gbc.gridx = 0; gbc.gridy = 3; inputPanel.add(fileLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        JPanel fileSelectionPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(fileSelectionPanel); // Apply theme to nested panel
        fileSelectionPanel.add(filePathField, BorderLayout.CENTER);
        fileSelectionPanel.add(browseButton, BorderLayout.EAST);
        inputPanel.add(fileSelectionPanel, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 1; inputPanel.add(uploadButton, gbc);
        gbc.gridx = 1; gbc.gridy = 4; gbc.gridwidth = 1; inputPanel.add(clearAssignmentFieldsButton, gbc);


        // Table to display uploaded assignments
        JPanel viewDeleteAssignmentsPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(viewDeleteAssignmentsPanel);
        viewDeleteAssignmentsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "My Uploaded Assignments"));

        String[] assignmentColumnNames = {"Assignment ID", "Class ID", "Title", "Description", "File Name", "Upload Date"};
        DefaultTableModel assignmentTableModel = new DefaultTableModel(assignmentColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable assignmentTable = new JTable(assignmentTableModel);
        applyBlackAndWhiteTheme(assignmentTable);
        assignmentTable.getTableHeader().setBackground(Color.BLACK);
        assignmentTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane assignmentScrollPane = new JScrollPane(assignmentTable);
        applyBlackAndWhiteTheme(assignmentScrollPane);

        JButton deleteAssignmentButton = new JButton("Delete Selected Assignment");

        viewDeleteAssignmentsPanel.add(assignmentScrollPane, BorderLayout.CENTER);
        JPanel deleteAssignmentButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(deleteAssignmentButtonPanel);
        deleteAssignmentButtonPanel.add(deleteAssignmentButton);
        viewDeleteAssignmentsPanel.add(deleteAssignmentButtonPanel, BorderLayout.SOUTH);

        // --- Helper to refresh assignment table based on selected class ---
        Runnable refreshAssignmentTable = () -> {
            assignmentTableModel.setRowCount(0);
            ClassInfo selectedClass = (ClassInfo) classForAssignmentComboBox.getSelectedItem();
            if (selectedClass != null) {
                List<Assignment> assignmentsForClass = assignmentManager.getAssignmentsByClassId(selectedClass.getClassId());
                for (Assignment assign : assignmentsForClass) {
                    Path p = Paths.get(assign.getFilePath());
                    assignmentTableModel.addRow(new Object[]{
                            assign.getAssignmentId(), assign.getClassId(), assign.getTitle(),
                            assign.getDescription(), p.getFileName().toString(), assign.getUploadDate()
                    });
                }
            }
        };

        // Initial refresh if a class is pre-selected
        if (classForAssignmentComboBox.getItemCount() > 0 && classForAssignmentComboBox.getSelectedItem() != null) {
            refreshAssignmentTable.run();
        } else {
            // Add a placeholder row if no classes are available or selected
            assignmentTableModel.addRow(new Object[]{"No class selected or available", "", "", "", "", ""});
        }


        // --- Listeners for Assignment Panel ---
        browseButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                filePathField.setText(selectedFile.getAbsolutePath());
            }
        });

        uploadButton.addActionListener(e -> {
            ClassInfo selectedClass = (ClassInfo) classForAssignmentComboBox.getSelectedItem();
            String title = titleField.getText().trim();
            String description = descriptionArea.getText().trim();
            String sourceFilePathString = filePathField.getText().trim();

            if (selectedClass == null) {
                JOptionPane.showMessageDialog(this, "Please select a class for the assignment.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (title.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an assignment title.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (sourceFilePathString.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select a file to upload.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            File sourceFile = new File(sourceFilePathString);
            if (!sourceFile.exists() || !sourceFile.isFile()) {
                JOptionPane.showMessageDialog(this, "Selected file does not exist or is not a valid file.", "File Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String assignmentId = "ASN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            Assignment newAssignment = new Assignment(
                    assignmentId,
                    selectedClass.getClassId(),
                    tutorUser.getUserId(), // Current tutor is the uploader
                    title,
                    description,
                    "", // File path will be set by the manager after copying
                    LocalDate.now()
            );

            if (assignmentManager.addAssignment(newAssignment, sourceFile.toPath())) {
                JOptionPane.showMessageDialog(this, "Assignment uploaded successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshAssignmentTable.run();
                clearAssignmentFieldsButton.doClick(); // Clear fields after successful upload
            } else {
                JOptionPane.showMessageDialog(this, "Failed to upload assignment. Check console for details.", "Upload Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteAssignmentButton.addActionListener(e -> {
            int selectedRow = assignmentTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an assignment to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String assignmentIdToDelete = (String) assignmentTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete assignment ID: " + assignmentIdToDelete + "? This will also delete the uploaded file.", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (assignmentManager.deleteAssignment(assignmentIdToDelete)) {
                    JOptionPane.showMessageDialog(this, "Assignment " + assignmentIdToDelete + " deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshAssignmentTable.run();
                    clearAssignmentFieldsButton.doClick();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete assignment " + assignmentIdToDelete + ".", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        clearAssignmentFieldsButton.addActionListener(e -> {
            if (classForAssignmentComboBox.getItemCount() > 0) classForAssignmentComboBox.setSelectedIndex(0);
            titleField.setText("");
            descriptionArea.setText("");
            filePathField.setText("");
            assignmentTable.clearSelection();
        });

        // Update assignment table when selected class changes
        classForAssignmentComboBox.addActionListener(e -> refreshAssignmentTable.run());

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(viewDeleteAssignmentsPanel, BorderLayout.CENTER);
        return panel;
    }

    // --- Panel: Update Profile (MODIFIED to allow updating name, email, contact) ---
    private JPanel createUpdateProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Update Own Profile (Tutor)"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userIdLabel = new JLabel("User ID:");
        JTextField userIdDisplayField = new JTextField(tutorUser.getUserId());
        userIdDisplayField.setEditable(false);
        applyBlackAndWhiteTheme(userIdDisplayField);

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(tutorUser.getName(), 20);
        applyBlackAndWhiteTheme(nameField);

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(tutorUser.getEmail(), 20);
        applyBlackAndWhiteTheme(emailField);

        JLabel contactLabel = new JLabel("Contact No.:");
        JTextField contactField = new JTextField(tutorUser.getContactNumber(), 20);
        applyBlackAndWhiteTheme(contactField);

        JLabel currentPasswordLabel = new JLabel("Current Password:");
        JPasswordField currentPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(currentPasswordField);

        JLabel newPasswordLabel = new JLabel("New Password:");
        JPasswordField newPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(newPasswordField);

        JLabel confirmNewPasswordLabel = new JLabel("Confirm New Password:");
        JPasswordField confirmNewPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(confirmNewPasswordField);

        JButton updateProfileButton = new JButton("Update Profile"); // Renamed button

        // Layout components
        gbc.gridx = 0; gbc.gridy = 0; panel.add(userIdLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; panel.add(userIdDisplayField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; panel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(emailLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; panel.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panel.add(contactLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; panel.add(contactField, gbc);

        gbc.gridx = 0; gbc.gridy = 4; panel.add(currentPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 4; panel.add(currentPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 5; panel.add(newPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 5; panel.add(newPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 6; panel.add(confirmNewPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 6; panel.add(confirmNewPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2; panel.add(updateProfileButton, gbc);

        updateProfileButton.addActionListener(e -> {
            String currentPass = new String(currentPasswordField.getPassword());
            String newPass = new String(newPasswordField.getPassword());
            String confirmNewPass = new String(confirmNewPasswordField.getPassword());

            // Validate current password (against the password stored in Authenticator/User)
            User basicUserFromAuth = authenticator.getUserById(tutorUser.getUserId());
            if (basicUserFromAuth == null || !currentPass.equals(basicUserFromAuth.getPassword())) {
                JOptionPane.showMessageDialog(this, "Current password incorrect.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean passwordChanged = false;
            if (!newPass.isEmpty()) { // Only attempt password change if newPass is provided
                if (!newPass.equals(confirmNewPass)) {
                    JOptionPane.showMessageDialog(this, "New password and confirmation do not match.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                // Update password in Authenticator
                if (!authenticator.updatePassword(tutorUser.getUserId(), newPass)) {
                    JOptionPane.showMessageDialog(this, "Failed to update password in authentication system.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                passwordChanged = true;
            }

            // Update detailed tutor profile (name, email, contact)
            tutorUser.setName(nameField.getText().trim());
            tutorUser.setEmail(emailField.getText().trim());
            tutorUser.setContactNumber(contactField.getText().trim());

            if (tutorDataManager.addOrUpdateTutor(tutorUser)) {
                if (passwordChanged) {
                    tutorUser = (Tutor) authenticator.getUserById(tutorUser.getUserId());
                }

                JOptionPane.showMessageDialog(this, "Profile updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                currentPasswordField.setText("");
                newPasswordField.setText("");
                confirmNewPasswordField.setText("");

                this.tutorUser = tutorDataManager.getTutorById(tutorUser.getUserId());
                if(this.tutorUser == null) {
                    this.tutorUser = (Tutor) authenticator.getUserById(tutorUser.getUserId());
                }

            } else {
                JOptionPane.showMessageDialog(this, "Failed to update profile details.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }
}