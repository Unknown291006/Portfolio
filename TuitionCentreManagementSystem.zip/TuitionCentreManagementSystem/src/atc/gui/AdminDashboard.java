package atc.gui;

import atc.auth.Authenticator;
import atc.auth.PaymentReportService;
import atc.auth.TutorDataManager;
import atc.model.Admin;
import atc.model.Receptionist;
import atc.model.Tutor;
import atc.model.User;

// IMPORTS REQUIRED FOR STUDENT PAYMENT REPORT ---
import atc.data.StudentDataManager;
import atc.data.ClassDataManager;
import atc.model.Student;
import atc.model.CourseClass;
// ---------------------------------------------------

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.UUID; // If you use this for ID generation

public class AdminDashboard extends JFrame {
    private User adminUser;
    private Authenticator authenticator;
    private TutorDataManager tutorDataManager;
    private PaymentReportService paymentReportService;

    // Common UI elements
    private JTabbedPane tabbedPane;
    private JButton logoutButton;

    // Data for dropdowns (hardcoded for now)
    private final String[] LEVELS = {"Secondary 1", "Secondary 2", "Secondary 3", "Secondary 4", "Secondary 5"};
    private final String[] SUBJECTS = {"Mathematics", "Science", "English", "Physics", "Biology", "AddMath"};

    public AdminDashboard(User adminUser) {
        this.adminUser = adminUser;
        this.authenticator = new Authenticator();
        this.tutorDataManager = new TutorDataManager();
        this.paymentReportService = new PaymentReportService();

        setTitle("ATC Admin Dashboard - Welcome, " + adminUser.getUserId());
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        // Note: Your current applyBlackAndWhiteTheme recursively applies to children.

        applyBlackAndWhiteTheme(this);

        createComponents();
        addListeners();
        setVisible(true);
    }

    private void applyBlackAndWhiteTheme(Component component) {
        // This is your comprehensive theme method. Keeping it as is.
        component.setBackground(Color.WHITE);

        if (component instanceof JComponent) {
            JComponent jc = (JComponent) component;
            jc.setForeground(Color.BLACK);

            if (jc instanceof JPanel || jc instanceof JTabbedPane || jc instanceof JScrollPane || jc instanceof JViewport) {
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JLabel || jc instanceof JComboBox || jc instanceof JList || jc instanceof JMenuItem || jc instanceof JMenu) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
            }
            if (jc instanceof JTextField || jc instanceof JPasswordField || jc instanceof JTextArea) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            }
            if (jc instanceof JButton) {
                jc.setForeground(Color.WHITE);
                jc.setBackground(Color.BLACK);
                Border buttonBorder = BorderFactory.createLineBorder(Color.BLACK);
                jc.setBorder(buttonBorder);
            }
            if (jc instanceof JTable) {
                jc.setForeground(Color.BLACK);
                jc.setBackground(Color.WHITE);
                jc.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                JTable table = (JTable) jc;
                if (table.getTableHeader() != null) {
                    table.getTableHeader().setBackground(Color.BLACK);
                    table.getTableHeader().setForeground(Color.WHITE);
                }
            }
        }
        if (component instanceof JMenuBar) {
            component.setBackground(Color.WHITE);
            component.setForeground(Color.BLACK);
        }

        if (component instanceof Container) {
            for (Component child : ((Container) component).getComponents()) {
                applyBlackAndWhiteTheme(child);
            }
        }
    }

    private void createComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(mainPanel); // Apply theme to mainPanel

        JPanel topPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(topPanel); // Apply theme to topPanel
        JLabel titleLabel = new JLabel("Admin Control Panel", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 12));
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(logoutPanel); // Apply theme to logoutPanel
        logoutPanel.add(logoutButton);
        topPanel.add(logoutPanel, BorderLayout.EAST);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        applyBlackAndWhiteTheme(tabbedPane); // Apply theme to tabbedPane
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));

        // Existing Tabs (as per your code)
        tabbedPane.addTab("Manage Tutors", createManageTutorPanel());
        tabbedPane.addTab("Manage Receptionists", createManageReceptionistPanel());
        tabbedPane.addTab("Tutor Assignments Summary", createTutorAssignmentSummaryPanel()); // Renamed


        // --- ADD THE NEW STUDENT PAYMENT REPORT TAB HERE ---
        tabbedPane.addTab("Student Payment Report", createStudentPaymentReportPanel());
        // ---------------------------------------------------

        tabbedPane.addTab("Update Profile", createUpdateProfilePanel());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        add(mainPanel);
    }

    private void addListeners() {
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new LoginScreen(); // Assuming LoginScreen handles its own display
                dispose(); // Close the current AdminDashboard frame
            }
        });
    }

    // --- Panel: Manage Tutors (MODIFIED TO INCLUDE ALL TUTOR INFO) ---
    private JPanel createManageTutorPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        JPanel registerPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(registerPanel);
        registerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Register New Tutor Profile"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField newTutorIdField = new JTextField(15);
        JPasswordField newTutorPasswordField = new JPasswordField(15);
        JTextField newTutorNameField = new JTextField(20);
        JTextField newTutorEmailField = new JTextField(20);
        JTextField newTutorContactField = new JTextField(20);

        JList<String> subjectList = new JList<>(SUBJECTS);
        subjectList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        applyBlackAndWhiteTheme(subjectList);
        JScrollPane subjectScrollPane = new JScrollPane(subjectList);
        applyBlackAndWhiteTheme(subjectScrollPane);
        subjectScrollPane.setBorder(BorderFactory.createTitledBorder("Assigned Subjects"));
        subjectScrollPane.setPreferredSize(new Dimension(200, 100)); // Make it visible

        JList<String> levelList = new JList<>(LEVELS);
        levelList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        applyBlackAndWhiteTheme(levelList);
        JScrollPane levelScrollPane = new JScrollPane(levelList);
        applyBlackAndWhiteTheme(levelScrollPane);
        levelScrollPane.setBorder(BorderFactory.createTitledBorder("Assigned Levels"));
        levelScrollPane.setPreferredSize(new Dimension(200, 100)); // Make it visible


        JButton registerTutorButton = new JButton("Register Tutor");
        JButton clearFieldsButton = new JButton("Clear Fields"); // New clear button for registration

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; registerPanel.add(new JLabel("Tutor ID:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; registerPanel.add(newTutorIdField, gbc);

        gbc.gridx = 0; gbc.gridy = row; registerPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; registerPanel.add(newTutorPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = row; registerPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; registerPanel.add(newTutorNameField, gbc);

        gbc.gridx = 0; gbc.gridy = row; registerPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; registerPanel.add(newTutorEmailField, gbc);

        gbc.gridx = 0; gbc.gridy = row; registerPanel.add(new JLabel("Contact No.:"), gbc);
        gbc.gridx = 1; gbc.gridy = row++; registerPanel.add(newTutorContactField, gbc);

        // Add lists for subjects and levels
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; registerPanel.add(subjectScrollPane, gbc);
        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; registerPanel.add(levelScrollPane, gbc);
        row++;

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        applyBlackAndWhiteTheme(buttonsPanel);
        buttonsPanel.add(registerTutorButton);
        buttonsPanel.add(clearFieldsButton);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; registerPanel.add(buttonsPanel, gbc);


        JPanel viewDeletePanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(viewDeletePanel);
        viewDeletePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "View & Delete Tutors"));

        // Update table columns to show more detailed info
        String[] columnNames = {"User ID", "Name", "Email", "Contact No.", "Subjects", "Levels"};
        DefaultTableModel tutorTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable tutorTable = new JTable(tutorTableModel);
        applyBlackAndWhiteTheme(tutorTable);
        tutorTable.getTableHeader().setBackground(Color.BLACK);
        tutorTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(tutorTable);
        applyBlackAndWhiteTheme(scrollPane);

        JButton deleteTutorButton = new JButton("Delete Selected Tutor");

        viewDeletePanel.add(scrollPane, BorderLayout.CENTER);
        JPanel deleteButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(deleteButtonPanel);
        deleteButtonPanel.add(deleteTutorButton);
        viewDeletePanel.add(deleteButtonPanel, BorderLayout.SOUTH);

        Runnable refreshTutorTable = () -> {
            tutorTableModel.setRowCount(0);
            Collection<Tutor> tutors = tutorDataManager.getAllTutors(); // Get detailed tutors
            for (Tutor tutor : tutors) {
                // Ensure passwords are not shown in the general view
                String subjectsStr = String.join(", ", tutor.getAssignedSubjects());
                String levelsStr = String.join(", ", tutor.getAssignedLevels());
                tutorTableModel.addRow(new Object[]{
                        tutor.getUserId(),
                        tutor.getName(),
                        tutor.getEmail(),
                        tutor.getContactNumber(),
                        subjectsStr.isEmpty() ? "None" : subjectsStr,
                        levelsStr.isEmpty() ? "None" : levelsStr
                });
            }
        };
        refreshTutorTable.run(); // Populate on startup

        registerTutorButton.addActionListener(e -> {
            String id = newTutorIdField.getText().trim();
            String pass = new String(newTutorPasswordField.getPassword());
            String name = newTutorNameField.getText().trim();
            String email = newTutorEmailField.getText().trim();
            String contact = newTutorContactField.getText().trim();
            List<String> assignedSubjects = subjectList.getSelectedValuesList();
            List<String> assignedLevels = levelList.getSelectedValuesList();

            if (id.isEmpty() || pass.isEmpty() || name.isEmpty() || email.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all mandatory fields (ID, Password, Name, Email, Contact No.).", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 1. Register basic user in Authenticator
            Tutor basicTutorForAuth = new Tutor(id, pass);
            if (authenticator.addUser(basicTutorForAuth)) {
                // 2. Create and store detailed tutor profile in TutorDataManager
                Tutor newDetailedTutor = new Tutor(id, pass, name, email, contact, assignedSubjects, assignedLevels);
                tutorDataManager.addOrUpdateTutor(newDetailedTutor); // This will save the full profile

                JOptionPane.showMessageDialog(this, "Tutor " + id + " registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFieldsButton.doClick(); // Clear all fields
                refreshTutorTable.run(); // Refresh the table
                // Also refresh the Tutor Assignments Summary tab if it's visible or has a refresh method
            } else {
                JOptionPane.showMessageDialog(this, "Tutor ID " + id + " already exists.", "Registration Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        clearFieldsButton.addActionListener(e -> {
            newTutorIdField.setText("");
            newTutorPasswordField.setText("");
            newTutorNameField.setText("");
            newTutorEmailField.setText("");
            newTutorContactField.setText("");
            subjectList.clearSelection();
            levelList.clearSelection();
        });


        deleteTutorButton.addActionListener(e -> {
            int selectedRow = tutorTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a tutor to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String tutorIdToDelete = (String) tutorTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete tutor " + tutorIdToDelete + "? This will remove their login and all profile data.", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (authenticator.deleteUser(tutorIdToDelete)) {
                    tutorDataManager.deleteTutor(tutorIdToDelete); // Delete detailed profile
                    // Note: Deleting a tutor does NOT automatically delete their classes.
                    // Admin or Receptionist must manage class deletions separately if needed.
                    JOptionPane.showMessageDialog(this, "Tutor " + tutorIdToDelete + " deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshTutorTable.run();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete tutor " + tutorIdToDelete + ".", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(registerPanel, BorderLayout.NORTH);
        panel.add(viewDeletePanel, BorderLayout.CENTER);
        return panel;
    }

    // --- Panel: Manage Receptionists ---
    private JPanel createManageReceptionistPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        JPanel registerPanel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(registerPanel);
        registerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Register New Receptionist"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField newRecIdField = new JTextField(15);
        JPasswordField newRecPasswordField = new JPasswordField(15);
        JButton registerRecButton = new JButton("Register Receptionist");

        gbc.gridx = 0; gbc.gridy = 0; registerPanel.add(new JLabel("Receptionist ID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; registerPanel.add(newRecIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; registerPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; registerPanel.add(newRecPasswordField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; registerPanel.add(registerRecButton, gbc);

        JPanel viewDeletePanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(viewDeletePanel);
        viewDeletePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "View & Delete Receptionists"));

        String[] columnNames = {"User ID", "Password"};
        DefaultTableModel recTableModel = new DefaultTableModel(columnNames, 0);
        JTable recTable = new JTable(recTableModel);
        applyBlackAndWhiteTheme(recTable);
        recTable.getTableHeader().setBackground(Color.BLACK);
        recTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(recTable);
        applyBlackAndWhiteTheme(scrollPane);

        JButton deleteRecButton = new JButton("Delete Selected Receptionist");

        viewDeletePanel.add(scrollPane, BorderLayout.CENTER);
        JPanel deleteButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(deleteButtonPanel);
        deleteButtonPanel.add(deleteRecButton);
        viewDeletePanel.add(deleteButtonPanel, BorderLayout.SOUTH);

        Runnable refreshRecTable = () -> {
            recTableModel.setRowCount(0);
            Collection<User> receptionists = authenticator.getUsersByRole("receptionist");
            for (User rec : receptionists) {
                recTableModel.addRow(new Object[]{rec.getUserId(), rec.getPassword()});
            }
        };
        refreshRecTable.run();

        registerRecButton.addActionListener(e -> {
            String id = newRecIdField.getText().trim();
            String pass = new String(newRecPasswordField.getPassword());
            if (id.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Receptionist ID and Password cannot be empty.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (authenticator.addUser(new Receptionist(id, pass))) {
                JOptionPane.showMessageDialog(this, "Receptionist " + id + " registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                newRecIdField.setText("");
                newRecPasswordField.setText("");
                refreshRecTable.run();
            } else {
                JOptionPane.showMessageDialog(this, "Receptionist ID " + id + " already exists.", "Registration Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteRecButton.addActionListener(e -> {
            int selectedRow = recTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a receptionist to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String recIdToDelete = (String) recTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete receptionist " + recIdToDelete + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (authenticator.deleteUser(recIdToDelete)) {
                    JOptionPane.showMessageDialog(this, "Receptionist " + recIdToDelete + " deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshRecTable.run();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete receptionist " + recIdToDelete + ".", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(registerPanel, BorderLayout.NORTH);
        panel.add(viewDeletePanel, BorderLayout.CENTER);
        return panel;
    }

    // --- Panel: Tutor Assignments Summary (MODIFIED to be view-only) ---
    private JPanel createTutorAssignmentSummaryPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        // View current assignments (table)
        JPanel viewPanel = new JPanel(new BorderLayout());
        applyBlackAndWhiteTheme(viewPanel);
        viewPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Tutor Assignment Summary"));

        String[] summaryColumnNames = {"Tutor ID", "Name", "Assigned Subjects", "Assigned Levels"};
        DefaultTableModel summaryTableModel = new DefaultTableModel(summaryColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable summaryTable = new JTable(summaryTableModel);
        applyBlackAndWhiteTheme(summaryTable);
        summaryTable.getTableHeader().setBackground(Color.BLACK);
        summaryTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane summaryScrollPane = new JScrollPane(summaryTable);
        applyBlackAndWhiteTheme(summaryScrollPane);
        viewPanel.add(summaryScrollPane, BorderLayout.CENTER);

        // Add a refresh button for the summary
        JButton refreshSummaryButton = new JButton("Refresh Summary");
        JPanel refreshPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        applyBlackAndWhiteTheme(refreshPanel);
        refreshPanel.add(refreshSummaryButton);
        viewPanel.add(refreshPanel, BorderLayout.SOUTH);


        // Helper to refresh assignment summary table
        Runnable refreshAssignmentSummaryTable = () -> {
            summaryTableModel.setRowCount(0);
            List<Tutor> allTutors = new ArrayList<>(tutorDataManager.getAllTutors());
            allTutors.sort((t1, t2) -> t1.getUserId().compareToIgnoreCase(t2.getUserId())); // Sort by ID
            for (Tutor tutor : allTutors) {
                String subjects = String.join(", ", tutor.getAssignedSubjects());
                String levels = String.join(", ", tutor.getAssignedLevels());
                summaryTableModel.addRow(new Object[]{tutor.getUserId(), tutor.getName(), subjects.isEmpty() ? "None" : subjects, levels.isEmpty() ? "None" : levels});
            }
        };
        refreshAssignmentSummaryTable.run(); // Load initial data

        refreshSummaryButton.addActionListener(e -> refreshAssignmentSummaryTable.run());

        panel.add(viewPanel, BorderLayout.CENTER);
        return panel;
    }

    // --- NEW Panel: Student Payment Report ---
    private JPanel createStudentPaymentReportPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        applyBlackAndWhiteTheme(panel);

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        applyBlackAndWhiteTheme(controlPanel);
        JButton generateReportButton = new JButton("Generate Student Payment Report");
        controlPanel.add(generateReportButton);

        // Define column names for the student payment report
        String[] reportColumnNames = {"Day", "Subject", "Student ID", "Student Name", "Payment Status", "Balance Due / Paid Amount", "Subject Fee"};
        DefaultTableModel reportTableModel = new DefaultTableModel(reportColumnNames, 0);
        JTable reportTable = new JTable(reportTableModel);
        applyBlackAndWhiteTheme(reportTable);
        reportTable.getTableHeader().setBackground(Color.BLACK);
        reportTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(reportTable);
        applyBlackAndWhiteTheme(scrollPane);

        // Use the existing paymentReportService instance
        generateReportButton.addActionListener(e -> {
            reportTableModel.setRowCount(0); // Clear existing data

            // Call the new method from your existing service
            List<Object[]> reportData = paymentReportService.generateStudentPaymentReport();

            if (reportData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No student payment data available.", "No Data", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            for (Object[] row : reportData) {
                reportTableModel.addRow(row);
            }
        });

        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }


    // --- Panel: Update Profile ---
    private JPanel createUpdateProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        applyBlackAndWhiteTheme(panel);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Update Own Profile (Admin)"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userIdLabel = new JLabel("User ID:");
        JTextField userIdDisplayField = new JTextField(adminUser.getUserId());
        userIdDisplayField.setEditable(false);
        applyBlackAndWhiteTheme(userIdDisplayField);

        JLabel currentPasswordLabel = new JLabel("Current Password:");
        JPasswordField currentPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(currentPasswordField);

        JLabel newPasswordLabel = new JLabel("New Password:");
        JPasswordField newPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(newPasswordField);

        JLabel confirmNewPasswordLabel = new JLabel("Confirm New Password:");
        JPasswordField confirmNewPasswordField = new JPasswordField(20);
        applyBlackAndWhiteTheme(confirmNewPasswordField);

        JButton updatePasswordButton = new JButton("Update Password");

        gbc.gridx = 0; gbc.gridy = 0; panel.add(userIdLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; panel.add(userIdDisplayField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(currentPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; panel.add(currentPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(newPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; panel.add(newPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panel.add(confirmNewPasswordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; panel.add(confirmNewPasswordField, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; panel.add(updatePasswordButton, gbc);

        updatePasswordButton.addActionListener(e -> {
            String currentPass = new String(currentPasswordField.getPassword());
            String newPass = new String(newPasswordField.getPassword());
            String confirmNewPass = new String(confirmNewPasswordField.getPassword());

            if (!currentPass.equals(adminUser.getPassword())) {
                JOptionPane.showMessageDialog(this, "Current password incorrect.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (newPass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "New password cannot be empty.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!newPass.equals(confirmNewPass)) {
                JOptionPane.showMessageDialog(this, "New password and confirmation do not match.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (authenticator.updatePassword(adminUser.getUserId(), newPass)) {
                // Update the adminUser object's password in memory as well
                this.adminUser = authenticator.getUserById(adminUser.getUserId());

                JOptionPane.showMessageDialog(this, "Password updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                currentPasswordField.setText("");
                newPasswordField.setText("");
                confirmNewPasswordField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update password.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

}