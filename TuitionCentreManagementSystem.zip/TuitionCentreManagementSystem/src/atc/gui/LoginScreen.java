package atc.gui;
import atc.auth.Authenticator;
import atc.model.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginScreen extends JFrame {
    private Authenticator authenticator; // Our authentication logic handler
    private JTextField userIdField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel messageLabel;
    public LoginScreen() {
        authenticator = new Authenticator(); // Initialize the authenticator
        setTitle("Advanced Tuition Centre - Login");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close application when this window
        setLocationRelativeTo(null); // Center the window on the screen
        // --- Black and White UI Settings ---
        getContentPane().setBackground(Color.WHITE); // Set frame background to white
        UIManager.put("Label.foreground", Color.BLACK);
        UIManager.put("TextField.foreground", Color.BLACK);
        UIManager.put("PasswordField.foreground", Color.BLACK);
        UIManager.put("Button.foreground", Color.WHITE); // Button text color
        UIManager.put("Button.background", Color.BLACK); // Button background color
        UIManager.put("Panel.background", Color.WHITE); // Ensure panels also have white

        createComponents(); // Setup UI elements
        addListeners(); // Add button and field listeners
        setVisible(true); // Make the window visible
    }
    private void createComponents() {
        // Using GridBagLayout for flexible and robust layout
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE); // Ensure panel background is white
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL; // Components expand horizontally
        // Title Label
        JLabel titleLabel = new JLabel("Advanced Tuition Centre Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; // Column 0
        gbc.gridy = 0; // Row 0
        gbc.gridwidth = 2; // Span 2 columns
        gbc.anchor = GridBagConstraints.CENTER; // Center alignment
        panel.add(titleLabel, gbc);
        // User ID Label and Field
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("User ID:"), gbc);
        userIdField = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(userIdField, gbc);
        // Password Label and Field
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Password:"), gbc);
        passwordField = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 2; gbc.anchor = GridBagConstraints.WEST;
        panel.add(passwordField, gbc);
        // Login Button
        loginButton = new JButton("Login");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(loginButton, gbc);
        // Message Label (for displaying errors or messages)
        messageLabel = new JLabel("");
        messageLabel.setForeground(Color.RED); // Error messages in red
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(messageLabel, gbc);
        add(panel); // Add the main panel to the frame
    }
    private void addListeners() {
        // Action listener for the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        });
        // Allow pressing Enter in the password field to trigger login
        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        });
    }
    private int loginAttempts = 0; // Add this line
    private final int MAX_ATTEMPTS = 3; // Add this line

    private void attemptLogin() {
        String userId = userIdField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (userId.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please enter both user ID and password.");
            return;
        }

        User authenticatedUser = authenticator.authenticate(userId, password);

        if (authenticatedUser != null) {
            messageLabel.setText(""); // Clear any previous error message
            JOptionPane.showMessageDialog(this, "Login successful! Welcome, " + authenticatedUser.getUserId() + " (" + authenticatedUser.getRole() + ").", "Success", JOptionPane.INFORMATION_MESSAGE);
            openDashboard(authenticatedUser);
            dispose(); // Close login window
        } else {
            loginAttempts++; // Increment attempt counter
            if (loginAttempts >= MAX_ATTEMPTS) {
                JOptionPane.showMessageDialog(this, "Maximum login attempts reached. Application will exit.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                System.exit(0); // Exit application
            } else {
                messageLabel.setText("Invalid User ID or Password. Attempts left: " + (MAX_ATTEMPTS - loginAttempts));
                userIdField.setText("");
                passwordField.setText("");
                userIdField.requestFocusInWindow();
            }
        }
    }
    // Method to open the specific dashboard based on user role
    private void openDashboard(User user) {
        switch (user.getRole()) {
            case "admin":
                new AdminDashboard(user);
                break;
            case "receptionist":
                new ReceptionistDashboard(user);
                break;
            case "tutor":
                new TutorDashboard(user);
                break;
            case "student":
                new StudentDashboard(user);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Dashboard not found for role: " + user.getRole(),
                        "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}