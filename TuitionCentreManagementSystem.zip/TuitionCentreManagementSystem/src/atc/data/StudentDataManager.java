package atc.data;

import atc.model.Student;
import atc.model.SubjectChangeRequest; // Ensure this import is correct
import atc.data.ClassDataManager; // Ensure this import is present

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StudentDataManager {
    private static final String FILE_NAME = "students.txt";

    // Method to load all students from the file
    public static List<Student> loadStudents() {
        List<Student> students = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Student student = parseStudent(line);
                if (student != null) {
                    students.add(student);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("students.txt not found. Creating a new one.");
            // File will be created when saveStudents is called
        } catch (IOException e) {
            System.err.println("Error reading students.txt: " + e.getMessage());
        }
        return students;
    }

    // Method to save a list of students to the file
    public static void saveStudents(List<Student> students) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Student student : students) {
                writer.write(formatStudent(student));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing to students.txt: " + e.getMessage());
        }
    }

    // Helper method to parse a Student object from a line of text
    private static Student parseStudent(String line) {
        // userId,password,name,icPassport,email,contactNumber,address,level,enrolledSubjects(;-separated),balanceDue (this part will now be calculated)
        String[] parts = line.split(",", -1); // -1 to keep trailing empty strings
        // Expecting at least 9 parts (userId to enrolledSubjects)
        if (parts.length >= 9) {
            try {
                String userId = parts[0];
                String password = parts[1];
                String name = parts[2];
                String icPassport = parts[3];
                String email = parts[4];
                String contactNumber = parts[5];
                String address = parts[6];
                String level = parts[7];

                List<String> enrolledSubjects = new ArrayList<>();
                if (parts.length > 8 && !parts[8].isEmpty()) { // Check if subjects string is not empty and exists
                    enrolledSubjects = new ArrayList<>(Arrays.asList(parts[8].split(";")));
                }

                // *** CRITICAL CHANGE: Calculate balanceDue from classes.txt ***
                double balanceDue = ClassDataManager.calculateBalanceDue(enrolledSubjects);

                // Requests are handled in a separate file (requests.txt) or elsewhere
                // Initialize an empty list for pendingRequests upon loading
                List<SubjectChangeRequest> pendingRequests = new ArrayList<>(); // You might load these from a separate RequestManager if implemented

                return new Student(userId, password, name, icPassport, email, contactNumber,
                        address, level, enrolledSubjects, balanceDue, pendingRequests);
            } catch (NumberFormatException e) {
                System.err.println("Invalid number format during student parsing (e.g., in other fields): " + line + " - " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Error parsing student line: " + line + " - " + e.getMessage());
            }
        } else {
            System.err.println("Malformed line in students.txt: " + line + ". Expected at least 9 parts (userId to enrolledSubjects).");
        }
        return null;
    }

    // Helper method to format a Student object into a line of text for saving
    private static String formatStudent(Student student) {
        // userId,password,name,icPassport,email,contactNumber,address,level,enrolledSubjects(;-separated),balanceDue
        // We save the current balanceDue (which would be updated on payment), but it's re-calculated on load for consistency with classes.txt fees
        String subjects = String.join(";", student.getEnrolledSubjects());
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%.2f",
                student.getUserId(),
                student.getPassword(),
                student.getName(),
                student.getIcPassport(),
                student.getEmail(),
                student.getContactNumber(),
                student.getAddress(),
                student.getLevel(),
                subjects,
                student.getBalanceDue());
    }

    // Method to find a student by userId
    public static Student getStudentByUserId(String userId) {
        List<Student> students = loadStudents();
        return students.stream()
                .filter(s -> s.getUserId().equals(userId))
                .findFirst()
                .orElse(null);
    }

    public boolean deleteStudent(String studentId) {
        List<Student> students = loadStudents();
        boolean removed = students.removeIf(s -> s.getUserId().equals(studentId));
        if (removed) {
            saveStudents(students);
            return true;
        }
        return false;
    }

    // Method to update a student's data in the file
    public static void updateStudent(Student updatedStudent) {
        List<Student> students = loadStudents();
        boolean found = false;
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getUserId().equals(updatedStudent.getUserId())) {
                students.set(i, updatedStudent);
                found = true;
                break;
            }
        }
        if (found) {
            saveStudents(students);
        } else {
            System.err.println("Student with ID " + updatedStudent.getUserId() + " not found for update.");
        }
    }
}