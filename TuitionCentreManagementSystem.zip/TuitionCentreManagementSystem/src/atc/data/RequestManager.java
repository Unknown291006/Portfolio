package atc.data;

import atc.model.SubjectChangeRequest;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RequestManager {
    private static final String FILE_NAME = "requests.txt";

    public static List<SubjectChangeRequest> loadRequests() {
        List<SubjectChangeRequest> requests = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Assuming SubjectChangeRequest.fromString handles parsing from the file line
                SubjectChangeRequest request = SubjectChangeRequest.fromString(line);
                if (request != null) {
                    requests.add(request);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("requests.txt not found. No requests loaded.");
        } catch (IOException e) {
            System.err.println("Error reading requests.txt: " + e.getMessage());
        }
        return requests;
    }

    public static void saveRequests(List<SubjectChangeRequest> requests) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (SubjectChangeRequest request : requests) {
                // Assuming request.toString() correctly formats the object for saving
                writer.write(request.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing to requests.txt: " + e.getMessage());
        }
    }

    // Method to add a new request
    public static void addRequest(SubjectChangeRequest newRequest) {
        List<SubjectChangeRequest> requests = loadRequests();
        requests.add(newRequest);
        saveRequests(requests);
    }

    // Method to delete a request by its ID
    public static void deleteRequest(String requestId) {
        List<SubjectChangeRequest> requests = loadRequests();
        List<SubjectChangeRequest> updatedRequests = requests.stream()
                .filter(r -> !r.getRequestId().equals(requestId))
                .collect(Collectors.toList());
        if (updatedRequests.size() < requests.size()) { // If something was removed
            saveRequests(updatedRequests);
        } else {
            System.out.println("Request with ID " + requestId + " not found for deletion.");
        }
    }

    // Method to update an existing request
    // Made static for consistency with other manager methods
    public static void updateRequest(SubjectChangeRequest updatedRequest) {
        List<SubjectChangeRequest> requests = loadRequests();
        // Remove the old version (if it exists) and add the updated one
        requests.removeIf(r -> r.getRequestId().equals(updatedRequest.getRequestId()));
        requests.add(updatedRequest);
        saveRequests(requests);
    }

    // Method to get pending requests for a specific student
    public static List<SubjectChangeRequest> getPendingRequestsByStudentId(String studentId) {
        return loadRequests().stream()
                .filter(r -> r.getStudentId().equals(studentId) && r.getStatus().equalsIgnoreCase("Pending"))
                .collect(Collectors.toList());
    }

    // --- NEW METHOD ADDED FOR ReceptionistDashboard ---
    // Method to delete all requests associated with a specific student ID
    public static void deleteRequestsByStudent(String studentId) {
        List<SubjectChangeRequest> requests = loadRequests();
        // Remove all requests where the student ID matches
        requests.removeIf(r -> r.getStudentId().equals(studentId));
        saveRequests(requests);
    }
}