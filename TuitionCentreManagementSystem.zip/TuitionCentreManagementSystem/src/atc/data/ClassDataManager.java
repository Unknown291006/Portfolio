package atc.data;

import atc.model.CourseClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ClassDataManager {
    private static final String FILE_NAME = "classes.txt";

    public static List<CourseClass> loadClasses() {
        List<CourseClass> classes = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                CourseClass courseClass = parseClass(line);
                if (courseClass != null) {
                    classes.add(courseClass);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("classes.txt not found. Please ensure it exists.");
            // Optionally, create the file if it's truly meant to be empty initially
            // try (FileWriter writer = new FileWriter(FILE_NAME)) { /* close immediately / } catch (IOException ex) { / handle */ }
        } catch (IOException e) {
            System.err.println("Error reading classes.txt: " + e.getMessage());
        }
        return classes;
    }

    private static CourseClass parseClass(String line) {
        // CLS-1EE1322E,TP123,Mathematics,Secondary 1,50.00,MONDAY,12:00,1 hour
        String[] parts = line.split(",", -1);
        if (parts.length == 8) {
            try {
                String classId = parts[0];
                String tutorId = parts[1];
                String subjectName = parts[2];
                String level = parts[3];
                double fee = Double.parseDouble(parts[4]);
                String day = parts[5];
                String time = parts[6];
                String duration = parts[7];

                return new CourseClass(classId, tutorId, subjectName, level, fee, day, time, duration);
            } catch (NumberFormatException e) {
                System.err.println("Invalid number format in classes.txt: " + line + " - " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Error parsing class line: " + line + " - " + e.getMessage());
            }
        } else {
            System.err.println("Malformed line in classes.txt: " + line);
        }
        return null;
    }

    /**
     * Calculates the total fee for a list of subject names based on classes.txt.
     * It sums the fees for each unique subject name in the list.
     * If a subject name appears multiple times in classes.txt with different fees/levels,
     * it will take the fee of the first instance encountered when creating the map.
     * For more precision, you might need to pass level as well.
     *
     * @param enrolledSubjectNames A list of subject names the student is enrolled in.
     * @return The total balance due for the enrolled subjects.
     */
    public static double calculateBalanceDue(List<String> enrolledSubjectNames) {
        List<CourseClass> allClasses = loadClasses();
        // Create a map for quick lookup of subject name to its fee.
        // If a subject has multiple entries (e.g., "Mathematics" for different levels),
        // this will take the fee of the first "Mathematics" class it encounters.
        // For exact calculation, student's level for each subject should be considered,
        // which might require a more complex lookup (e.g., Map<String, Map<String, Double>> for subject -> level -> fee)
        // For simplicity and current setup, we sum based on just subject name.
        Map<String, Double> subjectFees = allClasses.stream()
                .collect(Collectors.toMap(CourseClass::getSubjectName, CourseClass::getFee, (existing, replacement) -> existing)); // Pick first fee for duplicate keys

        double totalBalance = 0.0;
        for (String subjectName : enrolledSubjectNames) {
            totalBalance += subjectFees.getOrDefault(subjectName, 0.0);
        }
        return totalBalance;
    }
}