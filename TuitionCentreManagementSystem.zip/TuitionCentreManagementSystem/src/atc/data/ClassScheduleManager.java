package atc.data;

import atc.model.SubjectClass;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClassScheduleManager {
    private static final String FILE_NAME = "classes.txt";

    public static List<SubjectClass> loadClassSchedules() {
        List<SubjectClass> schedules = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                SubjectClass subjectClass = SubjectClass.fromString(line);
                if (subjectClass != null) {
                    schedules.add(subjectClass);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(FILE_NAME + " not found. No class schedules loaded.");
        } catch (IOException e) {
            System.err.println("Error reading " + FILE_NAME + ": " + e.getMessage());
        }
        return schedules;
    }

    // You might add save methods here if Admin/Tutor needs to update schedules through the system.
    // For student side, we only need to load.
}