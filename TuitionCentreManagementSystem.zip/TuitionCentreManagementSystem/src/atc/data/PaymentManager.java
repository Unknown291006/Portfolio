package atc.data;

import atc.model.PaymentRecord;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class PaymentManager {
    private static final String PAYMENTS_FILE = "classes.txt";

    /**
     * Appends a new payment record to the payments file.
     * This method assumes the PaymentRecord object is fully prepared for saving.
     *
     * @param newPayment The PaymentRecord object to be added.
     */
    public static void addPayment(PaymentRecord newPayment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PAYMENTS_FILE, true))) { // true for append mode
            writer.write(newPayment.toFileString());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing new payment to " + PAYMENTS_FILE + ": " + e.getMessage());
        }
    }

    // Note: Loading of payments is primarily handled by PaymentReportService.
    // If there was a need for Receptionist to view ALL individual payments,
    // a loadAllPayments() method could be added here, similar to other managers.
}