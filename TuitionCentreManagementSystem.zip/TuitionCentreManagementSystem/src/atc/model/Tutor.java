package atc.model;

import java.util.ArrayList;
import java.util.List;

public class Tutor extends User {
    private String name;
    private String email;
    private String contactNumber;
    private List<String> assignedSubjects;
    private List<String> assignedLevels;

    // Constructor for basic creation (e.g., from Authenticator)
    public Tutor(String userId, String password) {
        super(userId, password, "tutor");
        this.name = ""; // Initialize with empty string
        this.email = ""; // Initialize with empty string
        this.contactNumber = ""; // Initialize with empty string
        this.assignedSubjects = new ArrayList<>();
        this.assignedLevels = new ArrayList<>();
    }

    // Constructor for creating/loading a full tutor profile
    public Tutor(String userId, String password, String name, String email, String contactNumber,
                 List<String> assignedSubjects, List<String> assignedLevels) {
        super(userId, password, "tutor");
        this.name = name;
        this.email = email;
        this.contactNumber = contactNumber;
        this.assignedSubjects = assignedSubjects != null ? new ArrayList<>(assignedSubjects) : new ArrayList<>();
        this.assignedLevels = assignedLevels != null ? new ArrayList<>(assignedLevels) : new ArrayList<>();
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public List<String> getAssignedSubjects() {
        return assignedSubjects;
    }

    public List<String> getAssignedLevels() {
        return assignedLevels;
    }

    // Setters (for updating profile details and assignments)
    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setAssignedSubjects(List<String> assignedSubjects) {
        this.assignedSubjects = assignedSubjects != null ? new ArrayList<>(assignedSubjects) : new ArrayList<>();
    }

    public void setAssignedLevels(List<String> assignedLevels) {
        this.assignedLevels = assignedLevels != null ? new ArrayList<>(assignedLevels) : new ArrayList<>();
    }

    // Helper methods to add/remove single subject/level (optional, but good practice)
    public void addAssignedSubject(String subject) {
        if (!this.assignedSubjects.contains(subject)) {
            this.assignedSubjects.add(subject);
        }
    }

    public void removeAssignedSubject(String subject) {
        this.assignedSubjects.remove(subject);
    }

    public void addAssignedLevel(String level) {
        if (!this.assignedLevels.contains(level)) {
            this.assignedLevels.add(level);
        }
    }

    public void removeAssignedLevel(String level) {
        this.assignedLevels.remove(level);
    }

    @Override
    public String toString() {
        return "Tutor [ID=" + getUserId() + ", Name=" + name + ", Subjects=" + assignedSubjects + ", Levels=" + assignedLevels + "]";
    }
}