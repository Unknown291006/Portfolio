package atc.model;

import java.io.Serializable; // Good practice for file I/O

public class SubjectClass implements Serializable {
    private String subjectName;
    private String level; // e.g., "Form 1", "Form 2"
    private String tutorName; // Assuming tutor's name for display
    private String schedule; // e.g., "Mon 2:00 PM - 3:00 PM", "Tues/Thurs 4:00 PM - 5:30 PM"
    private double charges; // Monthly charges for the subject

    public SubjectClass(String subjectName, String level, String tutorName, String schedule, double charges) {
        this.subjectName = subjectName;
        this.level = level;
        this.tutorName = tutorName;
        this.schedule = schedule;
        this.charges = charges;
    }

    // Getters
    public String getSubjectName() {
        return subjectName;
    }

    public String getLevel() {
        return level;
    }

    public String getTutorName() {
        return tutorName;
    }

    public String getSchedule() {
        return schedule;
    }

    public double getCharges() {
        return charges;
    }

    // Setters (if needed for updates by tutor/admin, but not directly by student)
    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setCharges(double charges) {
        this.charges = charges;
    }

    @Override
    public String toString() {
        return subjectName + "," + level + "," + tutorName + "," + schedule + "," + charges;
    }

    // Static method to parse a SubjectClass from a CSV line
    public static SubjectClass fromString(String line) {
        String[] parts = line.split(",");
        if (parts.length == 5) {
            try {
                return new SubjectClass(
                        parts[0],       // subjectName
                        parts[1],       // level
                        parts[2],       // tutorName
                        parts[3],       // schedule
                        Double.parseDouble(parts[4]) // charges
                );
            } catch (NumberFormatException e) {
                System.err.println("Error parsing charges for SubjectClass: " + line);
                return null;
            }
        }
        return null;
    }
}