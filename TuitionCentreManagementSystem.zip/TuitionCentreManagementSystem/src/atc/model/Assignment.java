package atc.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Assignment implements Serializable {
    private static final long serialVersionUID = 1L; // Recommended for Serializable classes
    private String assignmentId;
    private String classId;
    private String tutorId;
    private String title;
    private String description;
    private String filePath; // Path to the uploaded file
    private LocalDate uploadDate;

    public Assignment(String assignmentId, String classId, String tutorId, String title, String description, String filePath, LocalDate uploadDate) {
        this.assignmentId = assignmentId;
        this.classId = classId;
        this.tutorId = tutorId;
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.uploadDate = uploadDate;
    }

    // Getters
    public String getAssignmentId() {
        return assignmentId;
    }

    public String getClassId() {
        return classId;
    }

    public String getTutorId() {
        return tutorId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getFilePath() {
        return filePath;
    }

    public LocalDate getUploadDate() {
        return uploadDate;
    }

    // Setters (if you need to modify an assignment after creation, e.g., update file path or details)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    // toString for easy debugging/display
    @Override
    public String toString() {
        return "Assignment{" +
                "assignmentId='" + assignmentId + '\'' +
                ", classId='" + classId + '\'' +
                ", tutorId='" + tutorId + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", filePath='" + filePath + '\'' +
                ", uploadDate=" + uploadDate +
                '}';
    }
}