package atc.model;

public class Receptionist extends User {
    public Receptionist(String userId, String password) {
        super(userId, password, "receptionist");
    }
}