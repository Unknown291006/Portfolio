package atc.model;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ClassInfo {
    private String classId;
    private String tutorId;
    private String subject;
    private String level;
    private double charges; // Per session, per month, etc.
    private List<DayOfWeek> scheduleDays;
    private LocalTime scheduleTime;
    private String duration; // e.g., "1 hour", "1.5 hours"

    // Constructor for creating new ClassInfo objects
    public ClassInfo(String classId, String tutorId, String subject, String level, double charges, List<DayOfWeek> scheduleDays, LocalTime scheduleTime, String duration) {
        this.classId = classId;
        this.tutorId = tutorId;
        this.subject = subject;
        this.level = level;
        this.charges = charges;
        this.scheduleDays = new ArrayList<>(scheduleDays); // Defensive copy
        this.scheduleTime = scheduleTime;
        this.duration = duration;
    }

    // Constructor for parsing from file line
    public ClassInfo(String line) throws IllegalArgumentException {
        String[] parts = line.split(",", 8); // Split by comma, expect 8 parts
        if (parts.length != 8) {
            throw new IllegalArgumentException("Invalid ClassInfo format: " + line);
        }
        try {
            this.classId = parts[0].trim();
            this.tutorId = parts[1].trim();
            this.subject = parts[2].trim();
            this.level = parts[3].trim();
            this.charges = Double.parseDouble(parts[4].trim());

            // Parse schedule days (e.g., "MONDAY;WEDNESDAY")
            String[] dayStrings = parts[5].trim().split(";");
            this.scheduleDays = Arrays.stream(dayStrings)
                    .map(DayOfWeek::valueOf)
                    .collect(Collectors.toList());

            this.scheduleTime = LocalTime.parse(parts[6].trim()); // e.g., "10:00"
            this.duration = parts[7].trim(); // e.g., "1 hour"

        } catch (IllegalArgumentException | DateTimeParseException e) {
            throw new IllegalArgumentException("Error parsing ClassInfo values: " + line, e);
        }
    }


    // Getters
    public String getClassId() { return classId; }
    public String getTutorId() { return tutorId; }
    public String getSubject() { return subject; }
    public String getLevel() { return level; }
    public double getCharges() { return charges; }
    public List<DayOfWeek> getScheduleDays() { return new ArrayList<>(scheduleDays); } // Defensive copy
    public LocalTime getScheduleTime() { return scheduleTime; }
    public String getDuration() { return duration; }

    // Setters (for updating)
    public void setSubject(String subject) { this.subject = subject; }
    public void setLevel(String level) { this.level = level; }
    public void setCharges(double charges) { this.charges = charges; }
    public void setScheduleDays(List<DayOfWeek> scheduleDays) { this.scheduleDays = new ArrayList<>(scheduleDays); }
    public void setScheduleTime(LocalTime scheduleTime) { this.scheduleTime = scheduleTime; }
    public void setDuration(String duration) { this.duration = duration; }

    // Method to convert to a line for saving to file
    public String toFileString() {
        String daysString = scheduleDays.stream()
                .map(DayOfWeek::name)
                .collect(Collectors.joining(";"));
        return String.format("%s,%s,%s,%s,%.2f,%s,%s,%s",
                classId, tutorId, subject, level, charges, daysString, scheduleTime.toString(), duration);
    }

    // For display in UI or debugging
    @Override
    public String toString() {
        return "ClassId: " + classId + ", Tutor: " + tutorId + ", Subject: " + subject + ", Level: " + level +
                ", Charges: " + charges + ", Schedule: " + scheduleDays + " at " + scheduleTime + ", Duration: " + duration;
    }
}