package atc.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SubjectChangeRequest implements Serializable {
    private String requestId;
    private String studentId;
    private String currentSubject; // Subject to drop (can be null if adding only)
    private String newSubject;     // Subject to add (can be null if dropping only)
    private String requestDate;    // Date and time of the request
    private String status;         // e.g., "Pending", "Approved", "Rejected"

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public SubjectChangeRequest(String studentId, String currentSubject, String newSubject) {
        this.requestId = generateRequestId(studentId); // Generate a unique ID
        this.studentId = studentId;
        this.currentSubject = currentSubject;
        this.newSubject = newSubject;
        this.requestDate = LocalDateTime.now().format(formatter);
        this.status = "Pending"; // Initial status
    }

    // Constructor for loading from file
    public SubjectChangeRequest(String requestId, String studentId, String currentSubject, String newSubject, String requestDate, String status) {
        this.requestId = requestId;
        this.studentId = studentId;
        this.currentSubject = currentSubject;
        this.newSubject = newSubject;
        this.requestDate = requestDate;
        this.status = status;
    }

    // Simple request ID generation (can be improved with UUID for robustness)
    private String generateRequestId(String studentId) {
        return studentId + "_" + System.currentTimeMillis();
    }

    // Getters
    public String getRequestId() {
        return requestId;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getCurrentSubject() {
        return currentSubject;
    }

    public String getNewSubject() {
        return newSubject;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public String getStatus() {
        return status;
    }

    // Setter for status (Receptionist will update this)
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        // Format for saving to file
        return String.join(",", requestId, studentId,
                currentSubject != null ? currentSubject : "null", // Handle nulls for optional fields
                newSubject != null ? newSubject : "null",
                requestDate, status);
    }

    // Static method to parse a SubjectChangeRequest from a CSV line
    public static SubjectChangeRequest fromString(String line) {
        String[] parts = line.split(",");
        if (parts.length == 6) {
            String current = "null".equals(parts[2]) ? null : parts[2];
            String newSub = "null".equals(parts[3]) ? null : parts[3];
            return new SubjectChangeRequest(parts[0], parts[1], current, newSub, parts[4], parts[5]);
        }
        return null;
    }
}