package atc.model;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Enrollment {
    private String enrollmentId;
    private String studentId;
    private String classId; // Refers to ClassInfo.classId
    private LocalDate enrollmentDate; // Changed to LocalDate

    // Constructor for creating a new Enrollment object programmatically
    public Enrollment(String enrollmentId, String studentId, String classId, LocalDate enrollmentDate) {
        this.enrollmentId = enrollmentId;
        this.studentId = studentId;
        this.classId = classId;
        this.enrollmentDate = enrollmentDate;
    }

    // Constructor to parse from a file line (String-based date)
    public Enrollment(String line) throws IllegalArgumentException {
        String[] parts = line.split(",");
        if (parts.length != 4) {
            throw new IllegalArgumentException("Invalid enrollment format: " + line);
        }
        this.enrollmentId = parts[0].trim();
        this.studentId = parts[1].trim();
        this.classId = parts[2].trim();
        try {
            this.enrollmentDate = LocalDate.parse(parts[3].trim());
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format in enrollment: " + parts[3].trim(), e);
        }
    }

    // Getters
    public String getEnrollmentId() { return enrollmentId; }
    public String getStudentId() { return studentId; }
    public String getClassId() { return classId; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }

    // Setters (if enrollment details can be updated)
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public void setClassId(String classId) { this.classId = classId; }
    public void setEnrollmentDate(LocalDate enrollmentDate) { this.enrollmentDate = enrollmentDate; }
    public void setEnrollmentDate(String enrollmentDateStr) {
        try {
            this.enrollmentDate = LocalDate.parse(enrollmentDateStr);
        } catch (DateTimeParseException e) {
            System.err.println("Warning: Could not parse enrollment date string: " + enrollmentDateStr + ". Date not set or set to null.");
            this.enrollmentDate = null;
        }
    }

    // Method to convert to a line for saving to file
    // Removed @Override from here
    public String toFileString() {
        return String.format("%s,%s,%s,%s", enrollmentId, studentId, classId, enrollmentDate.toString());
    }

    // These methods do override methods from the Object class, so @Override is correct here.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Enrollment that = (Enrollment) o;
        return enrollmentId.equals(that.enrollmentId);
    }

    @Override
    public int hashCode() {
        return enrollmentId.hashCode();
    }
}