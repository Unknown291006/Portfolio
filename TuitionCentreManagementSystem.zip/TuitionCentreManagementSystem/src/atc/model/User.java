package atc.model;
public abstract class User {
    private String userId;
    private String password;
    private String role; // e.g., "admin", "receptionist", "tutor", "student"
    public User(String userId, String password, String role) {
        this.userId = userId;
        this.password = password;
        this.role = role;
    }
    public String getUserId() {
        return userId;
    }
    public String getPassword() {
        return password;
    }
    public String getRole() {
        return role;
    }
    // You can add abstract methods here for user-specific behaviors later if needed
}