package atc.model;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
public class PaymentRecord {
    private String paymentId;
    private String studentId;
    private String level;
    private String subject;
    private double amount;
    private LocalDate date;
    public PaymentRecord(String paymentId, String studentId, String level, String subject, double
            amount, LocalDate date) {
        this.paymentId = paymentId;
        this.studentId = studentId;
        this.level = level;
        this.subject = subject;
        this.amount = amount;
        this.date = date;
    }
    // Constructor to parse from a file line (String)
    public PaymentRecord(String line) throws IllegalArgumentException {
        String[] parts = line.split(",");
        if (parts.length != 6) {
            throw new IllegalArgumentException("Invalid payment record format: " + line);
        }
        try {
            this.paymentId = parts[0].trim();
            this.studentId = parts[1].trim();
            this.level = parts[2].trim();
            this.subject = parts[3].trim();
            this.amount = Double.parseDouble(parts[4].trim());
            this.date = LocalDate.parse(parts[5].trim());
        } catch (NumberFormatException | DateTimeParseException e) {
            throw new IllegalArgumentException("Error parsing payment record values: " + line, e);
        }
    }
    // Getters
    public String getPaymentId() { return paymentId; }
    public String getStudentId() { return studentId; }
    public String getLevel() { return level; }
    public String getSubject() { return subject; }
    public double getAmount() { return amount; }
    public LocalDate getDate() { return date; }
    // Method to convert to a line for saving to file
    public String toFileString() {
        return String.format("%s,%s,%s,%s,%.2f,%s",
                paymentId, studentId, level, subject, amount, date.toString());
    }
}