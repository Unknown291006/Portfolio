package atc.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections; // For unmodifiable list
import java.util.List;
import javax.swing.JOptionPane; // Assuming for UI feedback, adjust if not using Swing

/**
 * Manages the loading and provision of available subjects for the system.
 * Subjects are read from a text file named "subjects.txt".
 */
public class SubjectManager {

    // Define the path to the subjects file.
    // This assumes 'subjects.txt' is in the root of your project or
    // in the directory where your application is run from.
    private static final String SUBJECTS_FILE_PATH = "subjects.txt";

    // A static list to cache the subjects once they are loaded.
    // This prevents re-reading the file every time getAvailableSubjects() is called.
    private static List<String> availableSubjectsCache = null;

    /**
     * Loads the list of subjects from the configured file path.
     * If subjects have already been loaded, it returns the cached list.
     * If loading fails, it displays an error message and returns an empty list.
     *
     * @return An unmodifiable List of subject names.
     */
    public static List<String> getAvailableSubjects() {
        // If subjects are already loaded, return the cached version
        if (availableSubjectsCache != null) {
            return Collections.unmodifiableList(availableSubjectsCache);
        }

        // If not loaded, proceed to read from file
        List<String> subjects = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(SUBJECTS_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String subjectName = line.trim();
                if (!subjectName.isEmpty()) { // Ensure we don't add empty lines
                    subjects.add(subjectName);
                }
            }
            // Cache the loaded subjects
            availableSubjectsCache = subjects;
            System.out.println("Successfully loaded subjects from: " + SUBJECTS_FILE_PATH);

        } catch (IOException e) {
            // Log the error for debugging
            System.err.println("Error reading subjects from file: " + SUBJECTS_FILE_PATH);
            e.printStackTrace(); // Print stack trace for detailed error info

            // Display a user-friendly error message
            JOptionPane.showMessageDialog(null,
                    "Failed to load available subjects. Please ensure '" + SUBJECTS_FILE_PATH + "' is in the correct location.",
                    "File Read Error",
                    JOptionPane.ERROR_MESSAGE);
            // Return an empty list if there's an error, so the application doesn't crash
            return Collections.emptyList();
        }

        // Return an unmodifiable list to prevent external modification of the cache
        return Collections.unmodifiableList(availableSubjectsCache);
    }

    // You can add a main method here for quick testing of this class
    public static void main(String[] args) {
        // Create a dummy subjects.txt for testing if it doesn't exist
        try {
            java.nio.file.Files.write(java.nio.file.Paths.get(SUBJECTS_FILE_PATH),
                    ("Mathematics\nScience\nEnglish\nBahasa Malaysia\nAdditional Mathematics\nPhysics\nChemistry\nBiology").getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> subjects = SubjectManager.getAvailableSubjects();
        if (subjects.isEmpty()) {
            System.out.println("No subjects loaded.");
        } else {
            System.out.println("Available Subjects:");
            for (String subject : subjects) {
                System.out.println("- " + subject);
            }
        }

        // Test caching (should not re-read file)
        List<String> subjects2 = SubjectManager.getAvailableSubjects();
        System.out.println("\nRetrieving subjects again (should be from cache):");
        for (String subject : subjects2) {
            System.out.println("- " + subject);
        }
    }
}