package atc.model;

public class CourseClass {
    private String classId;
    private String tutorId;
    private String subjectName;
    private String level;
    private double fee;
    private String day;
    private String time;
    private String duration;

    public CourseClass(String classId, String tutorId, String subjectName, String level, double fee, String day, String time, String duration) {
        this.classId = classId;
        this.tutorId = tutorId;
        this.subjectName = subjectName;
        this.level = level;
        this.fee = fee;
        this.day = day;
        this.time = time;
        this.duration = duration;
    }

    // Getters
    public String getClassId() {
        return classId;
    }

    public String getTutorId() {
        return tutorId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public String getLevel() {
        return level;
    }

    public double getFee() {
        return fee;
    }

    public String getDay() {
        return day;
    }

    public String getTime() {
        return time;
    }

    public String getDuration() {
        return duration;
    }

    @Override
    public String toString() {
        return "CourseClass{" +
                "classId='" + classId + '\'' +
                ", tutorId='" + tutorId + '\'' +
                ", subjectName='" + subjectName + '\'' +
                ", level='" + level + '\'' +
                ", fee=" + fee +
                ", day='" + day + '\'' +
                ", time='" + time + '\'' +
                ", duration='" + duration + '\'' +
                '}';
    }
}