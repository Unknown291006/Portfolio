package atc.model;

import java.util.ArrayList;
import java.util.List;

public class Student extends User {
    private String name;
    private String icPassport;
    private String email;
    private String contactNumber;
    private String address;
    private String level; // e.g., "Form 1", "Form 2", etc.
    private List<String> enrolledSubjects; // List of subject names student is enrolled in
    private double balanceDue; // Total balance student needs to pay
    private List<SubjectChangeRequest> pendingRequests; // List of pending subject change requests

    // THIS IS THE CONSTRUCTOR TO ADD/ENSURE IS PRESENT
    public Student(String userId, String password) {
        super(userId, password, "student");
        // Initialize default values for other fields when created this way
        this.name = ""; // Default empty string
        this.icPassport = "";
        this.email = "";
        this.contactNumber = "";
        this.address = "";
        this.level = ""; // Or a default form level like "Form 1"
        this.enrolledSubjects = new ArrayList<>();
        this.balanceDue = 0.0;
        this.pendingRequests = new ArrayList<>();
    }

    // Your existing constructor for new student (called by Receptionist, or for initial setup)
    public Student(String userId, String password, String name, String icPassport, String email,
                   String contactNumber, String address, String level) {
        super(userId, password, "student");
        this.name = name;
        this.icPassport = icPassport;
        this.email = email;
        this.contactNumber = contactNumber;
        this.address = address;
        this.level = level;
        this.enrolledSubjects = new ArrayList<>(); // Initialize empty list
        this.balanceDue = 0.0; // Initially no balance
        this.pendingRequests = new ArrayList<>();
    }

    // Your existing constructor for loading from file (includes all fields)
    public Student(String userId, String password, String name, String icPassport, String email,
                   String contactNumber, String address, String level, List<String> enrolledSubjects,
                   double balanceDue, List<SubjectChangeRequest> pendingRequests) {
        super(userId, password, "student");
        this.name = name;
        this.icPassport = icPassport;
        this.email = email;
        this.contactNumber = contactNumber;
        this.address = address;
        this.level = level;
        this.enrolledSubjects = enrolledSubjects != null ? enrolledSubjects : new ArrayList<>();
        this.balanceDue = balanceDue;
        this.pendingRequests = pendingRequests != null ? pendingRequests : new ArrayList<>();
    }

    // ... (rest of your getters and setters, including setPendingRequests, remain the same) ...

    // Getters
    public String getName() {
        return name;
    }

    public String getIcPassport() {
        return icPassport;
    }

    public String getEmail() {
        return email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public String getLevel() {
        return level;
    }

    public List<String> getEnrolledSubjects() {
        return enrolledSubjects;
    }

    public double getBalanceDue() {
        return balanceDue;
    }

    public List<SubjectChangeRequest> getPendingRequests() {
        return pendingRequests;
    }

    // Setters (for updating profile and other student data)
    public void setName(String name) {
        this.name = name;
    }

    public void setIcPassport(String icPassport) {
        this.icPassport = icPassport;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setEnrolledSubjects(List<String> enrolledSubjects) {
        this.enrolledSubjects = enrolledSubjects;
    }

    public void addEnrolledSubject(String subject) {
        if (!this.enrolledSubjects.contains(subject)) {
            this.enrolledSubjects.add(subject);
        }
    }

    public void removeEnrolledSubject(String subject) {
        this.enrolledSubjects.remove(subject);
    }

    public void setBalanceDue(double balanceDue) {
        this.balanceDue = balanceDue;
    }

    public void addPendingRequest(SubjectChangeRequest request) {
        this.pendingRequests.add(request);
    }

    public void setPendingRequests(List<SubjectChangeRequest> pendingRequests) {
        this.pendingRequests = pendingRequests;
    }

    public void removePendingRequest(SubjectChangeRequest request) {
        this.pendingRequests.remove(request);
    }

    // You might want to override toString for easier debugging/file writing
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getUserId()).append(",");
        sb.append(getPassword()).append(",");
        sb.append(getName()).append(",");
        sb.append(getIcPassport()).append(",");
        sb.append(getEmail()).append(",");
        sb.append(getContactNumber()).append(",");
        sb.append(getAddress()).append(",");
        sb.append(getLevel()).append(",");
        sb.append(String.join(";", enrolledSubjects)).append(","); // Subjects separated by semicolon
        sb.append(balanceDue);
        return sb.toString();
    }
}