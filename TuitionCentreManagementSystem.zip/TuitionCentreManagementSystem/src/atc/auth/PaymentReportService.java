package atc.auth; // Or atc.service, depending on your actual package

import atc.model.PaymentRecord;
import atc.data.StudentDataManager; // Import StudentDataManager
import atc.data.ClassDataManager; // Import ClassDataManager
import atc.model.Student; // Import Student model
import atc.model.CourseClass; // Import CourseClass model

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Comparator; // For sorting
import java.util.stream.Collectors;

public class PaymentReportService {
    private static final String PAYMENTS_FILE = "payments.txt";
    private List<PaymentRecord> allPayments;

    public PaymentReportService() {
        allPayments = new ArrayList<>();
        loadPayments();
    }

    private void loadPayments() {
        try (BufferedReader reader = new BufferedReader(new FileReader(PAYMENTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        allPayments.add(new PaymentRecord(line));
                    } catch (IllegalArgumentException e) {
                        System.err.println("Skipping malformed payment record: " + line + " - " +
                                e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading payments file: " + e.getMessage());
            try {
                new FileWriter(PAYMENTS_FILE).close(); // Create empty file if not found
            } catch (IOException ex) {
                System.err.println("Could not create empty payments.txt: " + ex.getMessage());
            }
        }
    }

    /**
     * Generates a monthly income report aggregated by level and subject.
     * @param yearMonth The specific year and month for the report.
     * @return A map where key is "Level - Subject" and value is total income.
     */
    public Map<String, Double> getMonthlyIncomeReport(YearMonth yearMonth) {
        Map<String, Double> report = new HashMap<>();
        for (PaymentRecord payment : allPayments) {
            if (YearMonth.from(payment.getDate()).equals(yearMonth)) {
                String key = payment.getLevel() + " - " + payment.getSubject();
                report.put(key, report.getOrDefault(key, 0.0) + payment.getAmount());
            }
        }
        return report;
    }

    // Helper to get all months for which data exists (for dropdowns)
    public List<YearMonth> getAvailableReportMonths() {
        return allPayments.stream()
                .map(payment -> YearMonth.from(payment.getDate()))
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Generates a payment report for all students, ordered by day, subjects and student ID.
     * Includes payment status (Paid/Outstanding) and total amount due.
     *
     * @return A list of Object arrays, each representing a row in the report table.
     * Columns: Day, Subject Name, Student ID, Student Name, Payment Status, Balance Due / Paid Amount, Subject Fee
     */
    public List<Object[]> generateStudentPaymentReport() {
        List<Student> allStudents = StudentDataManager.loadStudents();
        List<CourseClass> allClasses = ClassDataManager.loadClasses(); // Load all classes to get day/subject info

        // Create a map for quick lookup of CourseClass by subject name and level
        // This handles cases where different levels of the same subject might exist.
        Map<String, List<CourseClass>> classesBySubjectNameAndLevel = allClasses.stream()
                .collect(Collectors.groupingBy(cc -> cc.getSubjectName() + "|" + cc.getLevel()));

        List<Object[]> reportData = new ArrayList<>();

        for (Student student : allStudents) {
            double totalOutstanding = student.getBalanceDue();
            String paymentStatus = totalOutstanding > 0.0 ? "Outstanding" : "Paid";

            if (student.getEnrolledSubjects().isEmpty()) {
                reportData.add(new Object[]{
                        "N/A",           // Day
                        "No Subjects Enrolled",   // Subject Name
                        student.getUserId(),
                        student.getName(),
                        paymentStatus,
                        String.format("%.2f", totalOutstanding) + (totalOutstanding > 0 ? " (Owed)" : " (Paid)"),
                        "0.00" // No subject fee if no subjects
                });
            } else {
                for (String enrolledSubjectName : student.getEnrolledSubjects()) {
                    // Try to find the specific class for this subject and the student's level
                    List<CourseClass> relevantClasses = classesBySubjectNameAndLevel.get(enrolledSubjectName + "|" + student.getLevel());

                    String day = "N/A";
                    double subjectFee = 0.0;
                    if (relevantClasses != null && !relevantClasses.isEmpty()) {
                        CourseClass matchingClass = relevantClasses.get(0); // Should be unique for subject+level
                        day = matchingClass.getDay();
                        subjectFee = matchingClass.getFee();
                    }

                    reportData.add(new Object[]{
                            day,
                            enrolledSubjectName,
                            student.getUserId(),
                            student.getName(),
                            paymentStatus, // Status for the student's overall balance
                            String.format("%.2f", totalOutstanding) + (totalOutstanding > 0 ? " (Owed)" : " (Paid)"),
                            String.format("%.2f", subjectFee) // Fee for this specific subject
                    });
                }
            }
        }

        // Sort the report data: Day -> Subject -> Student ID
        reportData.sort((row1, row2) -> {
            String day1 = (String) row1[0];
            String day2 = (String) row2[0];
            int dayCompare = compareDays(day1, day2);
            if (dayCompare != 0) {
                return dayCompare;
            }

            String subject1 = (String) row1[1];
            String subject2 = (String) row2[1];
            int subjectCompare = subject1.compareTo(subject2);
            if (subjectCompare != 0) {
                return subjectCompare;
            }

            String studentId1 = (String) row1[2];
            String studentId2 = (String) row2[2];
            return studentId1.compareTo(studentId2);
        });

        return reportData;
    }

    // Helper method to compare days of the week in a specific order
    private int compareDays(String day1, String day2) {
        List<String> dayOrder = List.of(
                "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY", "N/A"
        );
        int index1 = dayOrder.indexOf(day1.toUpperCase());
        int index2 = dayOrder.indexOf(day2.toUpperCase());
        return Integer.compare(index1, index2);
    }
}