package atc.auth;

import atc.model.ClassInfo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ClassManager {
    private static final String CLASSES_FILE = "classes.txt";
    private List<ClassInfo> classes;

    public ClassManager() {
        classes = new ArrayList<>();
        loadClasses();
    }

    private void loadClasses() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CLASSES_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        classes.add(new ClassInfo(line));
                    } catch (IllegalArgumentException e) {
                        System.err.println("Skipping malformed class info record: " + line + " - " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading classes file: " + e.getMessage());
            try {
                new FileWriter(CLASSES_FILE).close(); // Create empty file if it doesn't exist
            } catch (IOException ex) {
                System.err.println("Could not create empty classes.txt: " + ex.getMessage());
            }
        }
    }

    private void saveClasses() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CLASSES_FILE))) {
            for (ClassInfo classInfo : classes) {
                writer.write(classInfo.toFileString() + System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("Error writing classes file: " + e.getMessage());
        }
    }

    public boolean addClass(ClassInfo newClass) {
        // Ensure classId is unique
        if (classes.stream().anyMatch(c -> c.getClassId().equals(newClass.getClassId()))) {
            return false; // Class ID already exists
        }
        classes.add(newClass);
        saveClasses();
        return true;
    }

    public boolean updateClass(ClassInfo updatedClass) {
        for (int i = 0; i < classes.size(); i++) {
            if (classes.get(i).getClassId().equals(updatedClass.getClassId())) {
                classes.set(i, updatedClass);
                saveClasses();
                return true;
            }
        }
        return false; // Class not found
    }

    public boolean deleteClass(String classId) {
        boolean removed = classes.removeIf(c -> c.getClassId().equals(classId));
        if (removed) {
            saveClasses();
        }
        return removed;
    }

    public List<ClassInfo> getAllClasses() {
        return new ArrayList<>(classes); // Return a copy
    }

    public List<ClassInfo> getClassesByTutor(String tutorId) {
        return classes.stream()
                .filter(c -> c.getTutorId().equalsIgnoreCase(tutorId))
                .collect(Collectors.toList());
    }

    public Optional<ClassInfo> getClassById(String classId) {
        return classes.stream()
                .filter(c -> c.getClassId().equals(classId))
                .findFirst();
    }

    // NEW METHOD: Added for filtering classes by subject and level
    public List<ClassInfo> getClassesBySubjectAndLevel(String subject, String level) {
        return classes.stream()
                .filter(c -> c.getSubject().equalsIgnoreCase(subject) && c.getLevel().equalsIgnoreCase(level))
                .collect(Collectors.toList());
    }
}