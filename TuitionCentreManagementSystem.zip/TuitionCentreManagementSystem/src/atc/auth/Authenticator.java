package atc.auth;
import atc.model.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection; // Added for getAllUsers
import java.util.HashMap;
import java.util.Map;
public class Authenticator {
    private static final String USERS_FILE = "users.txt";
    private Map<String, User> users;
    public Authenticator() {
        users = new HashMap<>();
        loadUsers();
    }
    private void loadUsers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String userId = parts[0].trim();
                    String password = parts[1].trim();
                    String role = parts[2].trim().toLowerCase();
                    User user = null;
                    switch (role) {
                        case "admin":
                            user = new Admin(userId, password);
                            break;
                        case "receptionist":
                            user = new Receptionist(userId, password);
                            break;
                        case "tutor":
                            user = new Tutor(userId, password);
                            break;
                        case "student":
                            user = new Student(userId, password);
                            break;
                        default:
                            System.err.println("Unknown role found in users.txt: " + role);
                            break;
                    }
                    if (user != null) {
                        users.put(userId, user);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading users file '" + USERS_FILE + "': " + e.getMessage());
            System.err.println("Please make sure '" + USERS_FILE + "' is in the project root directory. Creating an empty one if it doesn't exist.");
            try {
                new FileWriter(USERS_FILE).close(); // Create empty file
            } catch (IOException ex) {
                System.err.println("Could not create empty users.txt: " + ex.getMessage());
            }
        }
    }
    // New method to save current users to file
    public void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users.values()) {
                writer.write(String.format("%s,%s,%s%n", user.getUserId(), user.getPassword(),
                        user.getRole()));
            }
        } catch (IOException e) {
            System.err.println("Error writing users file: " + e.getMessage());
        }
    }
    public User authenticate(String userId, String password) {
        User user = users.get(userId);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
    // New method to add a user
    public boolean addUser(User user) {
        if (users.containsKey(user.getUserId())) {
            return false; // User ID already exists
        }
        users.put(user.getUserId(), user);
        saveUsers(); // Save changes immediately
        return true;
    }
    // New method to delete a user
    public boolean deleteUser(String userId) {
        if (users.remove(userId) != null) {
            saveUsers(); // Save changes immediately
            return true;
        }
        return false; // User not found
    }
    // New method to get all users of a specific role
    public Collection<User> getUsersByRole(String role) {
        return users.values().stream()
                .filter(user -> user.getRole().equalsIgnoreCase(role))
                .collect(java.util.ArrayList::new, java.util.ArrayList::add, java.util.ArrayList::addAll);
    }
    // New method to get a user by ID
    public User getUserById(String userId) {
        return users.get(userId);
    }
    // New method to update a user's password (for "Update own profile")
    public boolean updatePassword(String userId, String newPassword) {
        User user = users.get(userId);
        if (user != null) {
            // This is a simple update. In a real scenario, you'd likely update the User object'spassword directly,
            // or pass it to a method that creates a new User object with updated password if User was immutable.
            // For now, we'll recreate the user and put it back in the map.
            User updatedUser = null;
            switch(user.getRole()){
                case "admin": updatedUser = new Admin(userId, newPassword); break;
                case "receptionist": updatedUser = new Receptionist(userId, newPassword); break;
                case "tutor": updatedUser = new Tutor(userId, newPassword); break;
                case "student": updatedUser = new Student(userId, newPassword); break;
            }
            if(updatedUser != null) {
                users.put(userId, updatedUser); // Replace the old user object
                saveUsers();
                return true;
            }
        }
        return false;
    }
}