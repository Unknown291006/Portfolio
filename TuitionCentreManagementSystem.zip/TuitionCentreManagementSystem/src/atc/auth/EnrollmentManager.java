package atc.auth;

import atc.model.Enrollment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EnrollmentManager {
    private static final String ENROLLMENTS_FILE = "enrollments.txt";
    private List<Enrollment> enrollments;

    public EnrollmentManager() {
        enrollments = new ArrayList<>();
        loadEnrollments();
    }

    private void loadEnrollments() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ENROLLMENTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        enrollments.add(new Enrollment(line));
                    } catch (IllegalArgumentException e) {
                        System.err.println("Skipping malformed enrollment record: " + line + " - " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading enrollments file: " + e.getMessage());
            try {
                new FileWriter(ENROLLMENTS_FILE).close(); // Create empty file if it doesn't exist
            } catch (IOException ex) {
                System.err.println("Could not create empty enrollments.txt: " + ex.getMessage());
            }
        }
    }

    private void saveEnrollments() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ENROLLMENTS_FILE))) {
            for (Enrollment enrollment : enrollments) {
                writer.write(enrollment.toFileString() + System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("Error writing enrollments file: " + e.getMessage());
        }
    }

    public boolean addEnrollment(Enrollment newEnrollment) {
        // Prevent duplicate enrollments (same student, same class)
        if (enrollments.stream().anyMatch(e -> e.getStudentId().equals(newEnrollment.getStudentId()) &&
                e.getClassId().equals(newEnrollment.getClassId()))) {
            return false;
        }
        enrollments.add(newEnrollment);
        saveEnrollments();
        return true;
    }

    public List<Enrollment> getEnrollmentsByClass(String classId) {
        return enrollments.stream()
                .filter(e -> e.getClassId().equals(classId))
                .collect(Collectors.toList());
    }

    public List<Enrollment> getEnrollmentsByStudent(String studentId) {
        return enrollments.stream()
                .filter(e -> e.getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }

    public boolean deleteEnrollment(String enrollmentId) {
        boolean removed = enrollments.removeIf(e -> e.getEnrollmentId().equals(enrollmentId));
        if (removed) {
            saveEnrollments();
        }
        return removed;
    }

    /**
     * Deletes all enrollments associated with a specific class ID.
     * This is useful when a class is deleted.
     * @param classId The ID of the class whose enrollments are to be deleted.
     * @return true if any enrollments were removed, false otherwise.
     */
    public boolean deleteEnrollmentsByClassId(String classId) {
        // Collect enrollments to remove first to avoid ConcurrentModificationException
        List<Enrollment> toRemove = enrollments.stream()
                .filter(e -> e.getClassId().equals(classId))
                .collect(Collectors.toList());
        if (!toRemove.isEmpty()) {
            enrollments.removeAll(toRemove);
            saveEnrollments();
            return true;
        }
        return false;
    }

    public List<Enrollment> getAllEnrollments() {
        return new ArrayList<>(enrollments);
    }
}