package atc.auth;
import java.util.Collection;
import atc.model.Tutor;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection; // Added this import
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class TutorDataManager {
    private static final String TUTORS_DATA_FILE = "tutors_data.txt";
    private Map<String, Tutor> tutorDataMap; // Stores detailed Tutor objects by userId

    public TutorDataManager() {
        tutorDataMap = new ConcurrentHashMap<>();
        loadTutorsData();
    }

    private void loadTutorsData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(TUTORS_DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Format: userId;password;name;email;contactNumber;subjects;levels
                // We split into 7 parts to ensure subjects and levels are treated as single strings
                String[] parts = line.split(";", 7);
                if (parts.length == 7) {
                    String userId = parts[0].trim();
                    String password = parts[1].trim();
                    String name = parts[2].trim();
                    String email = parts[3].trim();
                    String contactNumber = parts[4].trim();

                    // Parse subjects (comma-separated, can be empty)
                    List<String> assignedSubjects = parts[5].trim().isEmpty() ?
                            new ArrayList<>() : Arrays.asList(parts[5].trim().split(","));

                    // Parse levels (comma-separated, can be empty)
                    List<String> assignedLevels = parts[6].trim().isEmpty() ?
                            new ArrayList<>() : Arrays.asList(parts[6].trim().split(","));

                    Tutor tutor = new Tutor(userId, password, name, email, contactNumber, assignedSubjects, assignedLevels);
                    tutorDataMap.put(userId, tutor);
                } else {
                    System.err.println("Skipping malformed line in " + TUTORS_DATA_FILE + ": " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading tutors data file '" + TUTORS_DATA_FILE + "': " + e.getMessage());
            System.err.println("Creating an empty '" + TUTORS_DATA_FILE + "' if it doesn't exist.");
            try {
                new FileWriter(TUTORS_DATA_FILE).close(); // Create empty file
            } catch (IOException ex) {
                System.err.println("Could not create empty " + TUTORS_DATA_FILE + ": " + ex.getMessage());
            }
        }
    }

    public void saveTutorsData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TUTORS_DATA_FILE))) {
            for (Tutor tutor : tutorDataMap.values()) {
                // Format: userId;password;name;email;contactNumber;subjects (comma-separated);levels (comma-separated)
                String subjectsStr = String.join(",", tutor.getAssignedSubjects());
                String levelsStr = String.join(",", tutor.getAssignedLevels());
                writer.write(String.format("%s;%s;%s;%s;%s;%s;%s%n",
                        tutor.getUserId(),
                        tutor.getPassword(), // Password from the Tutor object (consistent with User)
                        tutor.getName(),
                        tutor.getEmail(),
                        tutor.getContactNumber(),
                        subjectsStr,
                        levelsStr));
            }
        } catch (IOException e) {
            System.err.println("Error writing tutors data file: " + e.getMessage());
        }
    }

    public Tutor getTutorById(String userId) {
        return tutorDataMap.get(userId);
    }

    public Collection<Tutor> getAllTutors() {
        return tutorDataMap.values();
    }

    /**
     * Adds a new detailed tutor profile or updates an existing one.
     * This should be called after a basic user is added via Authenticator.
     *
     * @param tutor The Tutor object with detailed information.
     * @return true if successful (added or updated), false if an error occurred.
     */
    public boolean addOrUpdateTutor(Tutor tutor) {
        if (tutor == null) {
            return false;
        }
        tutorDataMap.put(tutor.getUserId(), tutor);
        saveTutorsData();
        return true;
    }

    /**
     * Deletes a detailed tutor profile.
     * This should be called when a basic user is deleted via Authenticator.
     *
     * @param userId The ID of the tutor to delete.
     * @return true if deleted, false if not found.
     */
    public boolean deleteTutor(String userId) {
        if (tutorDataMap.remove(userId) != null) {
            saveTutorsData();
            return true;
        }
        return false;
    }

    /**
     * Updates only the assignments for a tutor.
     * @param tutorId The ID of the tutor.
     * @param newSubjects The new list of assigned subjects.
     * @param newLevels The new list of assigned levels.
     * @return true if updated, false if tutor not found.
     */
    public boolean updateTutorAssignments(String tutorId, List<String> newSubjects, List<String> newLevels) {
        Tutor tutor = tutorDataMap.get(tutorId);
        if (tutor != null) {
            tutor.setAssignedSubjects(newSubjects);
            tutor.setAssignedLevels(newLevels);
            saveTutorsData();
            return true;
        }
        return false;
    }
}