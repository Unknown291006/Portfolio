package atc.auth; // Or atc.service
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class TutorAssignmentManager {
    private static final String ASSIGNMENTS_FILE = "tutor_assignments.txt";
    // Stores assignments as simple strings: "tutorId,level,subject"
    private List<String> assignments;
    public TutorAssignmentManager() {
        assignments = new ArrayList<>();
        loadAssignments();
    }
    private void loadAssignments() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ASSIGNMENTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    assignments.add(line.trim());
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading tutor assignments file: " + e.getMessage());
            try {
                new FileWriter(ASSIGNMENTS_FILE).close(); // Create empty file
            } catch (IOException ex) {
                System.err.println("Could not create empty tutor_assignments.txt: " + ex.getMessage());
            }
        }
    }
    private void saveAssignments() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ASSIGNMENTS_FILE))) {
            for (String assignment : assignments) {
                writer.write(assignment + System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("Error writing tutor assignments file: " + e.getMessage());
        }
    }
    public boolean assignTutor(String tutorId, String level, String subject) {
        String newAssignment = String.format("%s,%s,%s", tutorId, level, subject);
        // Prevent duplicate assignments (same tutor, level, subject)
        if (assignments.contains(newAssignment)) {
            return false;
        }
        assignments.add(newAssignment);
        saveAssignments();
        return true;
    }
    // You might want a more sophisticated way to manage assignments (e.g., allow a tutor to teach multiple,
    // but not assign the same tutor to the same level/subject twice).
    // This simple implementation allows a tutor to teach multiple subjects/levels.
    public boolean removeAssignment(String tutorId, String level, String subject) {
        String assignmentToRemove = String.format("%s,%s,%s", tutorId, level, subject);
        boolean removed = assignments.remove(assignmentToRemove);
        if (removed) {
            saveAssignments();
        }
        return removed;
    }
    public List<String> getAssignments() {
        return new ArrayList<>(assignments); // Return a copy to prevent external modification
    }
    // Helper to get assignments for a specific tutor
    public List<String> getAssignmentsForTutor(String tutorId) {
        return assignments.stream()
                .filter(a -> a.startsWith(tutorId + ","))
                .collect(Collectors.toList());
    }
}