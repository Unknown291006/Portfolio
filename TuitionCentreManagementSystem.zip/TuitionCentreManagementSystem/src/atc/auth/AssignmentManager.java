package atc.auth;

import atc.model.Assignment;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class AssignmentManager {
    private static final String ASSIGNMENT_FILE = "data/assignments.ser";
    private static final String ASSIGNMENT_UPLOAD_DIR = "assignments_uploads/"; // Directory to save uploaded files
    private List<Assignment> assignments;

    public AssignmentManager() {
        // Ensure the data directory exists
        File dataDir = new File("data");
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }

        // Ensure the upload directory exists
        File uploadDir = new File(ASSIGNMENT_UPLOAD_DIR);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        loadAssignments();
    }

    @SuppressWarnings("unchecked")
    private void loadAssignments() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ASSIGNMENT_FILE))) {
            assignments = (List<Assignment>) ois.readObject();
        } catch (FileNotFoundException e) {
            assignments = new ArrayList<>();
            saveAssignments(); // Create the file if it doesn't exist
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading assignments: " + e.getMessage());
            assignments = new ArrayList<>(); // Initialize to empty list on error
        }
    }

    private void saveAssignments() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ASSIGNMENT_FILE))) {
            oos.writeObject(assignments);
        } catch (IOException e) {
            System.err.println("Error saving assignments: " + e.getMessage());
        }
    }

    /**
     * Adds a new assignment and copies the file to the designated upload directory.
     * @param assignment The Assignment object to add.
     * @param sourceFilePath The original path of the file to be uploaded.
     * @return true if assignment added successfully, false otherwise.
     */
    public boolean addAssignment(Assignment assignment, Path sourceFilePath) {
        if (getAssignmentById(assignment.getAssignmentId()).isPresent()) {
            return false; // Assignment with this ID already exists
        }

        // Copy the file to the assignments_uploads directory
        try {
            // Use the original file name, but prepend with assignment ID for uniqueness if desired
            // For now, just use original file name, assuming unique names or handling collisions in UI
            String fileName = sourceFilePath.getFileName().toString();
            Path destinationPath = Paths.get(ASSIGNMENT_UPLOAD_DIR, fileName);
            Files.copy(sourceFilePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            // Update the assignment's filePath to the path within our system
            assignment.setFilePath(destinationPath.toString());
        } catch (IOException e) {
            System.err.println("Error copying assignment file: " + e.getMessage());
            return false; // File copy failed
        }

        assignments.add(assignment);
        saveAssignments();
        return true;
    }

    public Optional<Assignment> getAssignmentById(String assignmentId) {
        return assignments.stream()
                .filter(a -> a.getAssignmentId().equals(assignmentId))
                .findFirst();
    }

    public List<Assignment> getAssignmentsByClassId(String classId) {
        return assignments.stream()
                .filter(a -> a.getClassId().equals(classId))
                .collect(Collectors.toList());
    }

    public List<Assignment> getAssignmentsByTutorId(String tutorId) {
        return assignments.stream()
                .filter(a -> a.getTutorId().equals(tutorId))
                .collect(Collectors.toList());
    }

    /**
     * Updates an existing assignment.
     * Note: This method does NOT handle file re-upload. If you need to change the file,
     * you should implement a separate method or delete and re-add the assignment.
     * @param updatedAssignment The Assignment object with updated details.
     * @return true if assignment updated successfully, false otherwise.
     */
    public boolean updateAssignment(Assignment updatedAssignment) {
        Optional<Assignment> existingAssignmentOpt = getAssignmentById(updatedAssignment.getAssignmentId());
        if (existingAssignmentOpt.isPresent()) {
            Assignment existingAssignment = existingAssignmentOpt.get();
            // Update fields (excluding filePath, as we're not handling file re-upload in this specific update method)
            existingAssignment.setTitle(updatedAssignment.getTitle());
            existingAssignment.setDescription(updatedAssignment.getDescription());
            // The file path remains the same as the original upload
            saveAssignments();
            return true;
        }
        return false;
    }

    public boolean deleteAssignment(String assignmentId) {
        Optional<Assignment> assignmentToDeleteOpt = getAssignmentById(assignmentId);
        if (assignmentToDeleteOpt.isPresent()) {
            Assignment assignmentToDelete = assignmentToDeleteOpt.get();
            // Delete the associated file from the uploads directory
            try {
                Path filePath = Paths.get(assignmentToDelete.getFilePath());
                Files.deleteIfExists(filePath);
            } catch (IOException e) {
                System.err.println("Error deleting assignment file: " + e.getMessage());
                // Log the error but proceed to delete the assignment record
            }

            boolean removed = assignments.removeIf(a -> a.getAssignmentId().equals(assignmentId));
            if (removed) {
                saveAssignments();
            }
            return removed;
        }
        return false;
    }
}