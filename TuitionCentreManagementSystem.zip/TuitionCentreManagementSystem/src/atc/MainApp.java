package atc;
import atc.gui.LoginScreen; // Import our login screen class
import javax.swing.SwingUtilities; // For ensuring GUI updates are safe
public class MainApp {
    public static void main(String[] args) {
        // Swing applications should always be started on the Event Dispatch Thread (EDT)
        // This ensures thread safety for GUI operations.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginScreen(); // Create and show the login screen
            }
        });
    }
}